#!/bin/bash

set -euo pipefail

export TABLE_PREFIX="aws_all"
export SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export CSV_DIR="${SCRIPT_DIR}/csv"
export OUTPUT_XLSX="${SCRIPT_DIR}/all_resources_consolidado_aws.xlsx"
export LOG_FILE="${SCRIPT_DIR}/erro_execucao.log"
export RESUMO_CSV="${CSV_DIR}/resumo_quantidade_linhas.csv"

mkdir -p "$CSV_DIR"
> "$LOG_FILE"

TABLE_LIST="${SCRIPT_DIR}/tables_query.txt"
[ ! -f "$TABLE_LIST" ] && { echo "Arquivo de tabelas não encontrado: $TABLE_LIST"; exit 1; }

while IFS= read -r table || [[ -n "$table" ]]; do
  [[ -z "$table" || "$table" =~ ^# ]] && continue
  csv_file="${CSV_DIR}/${table}.csv"
  echo -e "🚀 Iniciando: $table"

  if ! steampipe query --output csv "select * from ${TABLE_PREFIX}.${table};" > "$csv_file" 2>>"$LOG_FILE"; then
    echo "Erro na tabela $table" >> "$LOG_FILE"
    rm -f "$csv_file"
  else
    if [ "$(wc -l < "$csv_file")" -le 1 ]; then
      rm -f "$csv_file"
    fi
  fi
done < "$TABLE_LIST"

# Gerar resumo com nome dos CSVs e quantidade de linhas (sem o cabeçalho)
echo "arquivo,linhas" > "$RESUMO_CSV"

for csv_file in "$CSV_DIR"/*.csv; do
  if [ -f "$csv_file" ]; then
    linhas_total=$(wc -l < "$csv_file")
    linhas=$((linhas_total > 0 ? linhas_total - 1 : 0))
    nome_arquivo=$(basename "$csv_file")
    echo "${nome_arquivo},${linhas}" >> "$RESUMO_CSV"
  fi
done

echo "📝 Resumo salvo em: $RESUMO_CSV"

# Consolidação em Excel (resumo primeiro)
python3 - <<EOF
import pandas as pd
import os

csv_dir = "$CSV_DIR"
xlsx_path = "$OUTPUT_XLSX"
resumo_path = "$RESUMO_CSV"

with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
    # Escreve o resumo como primeira aba
    try:
        df_resumo = pd.read_csv(resumo_path)
        df_resumo.to_excel(writer, sheet_name="00_resumo", index=False)
    except Exception as e:
        print(f"❗ Erro ao adicionar resumo: {e}")

    # Escreve os demais CSVs, exceto o próprio resumo
    for csv_file in sorted(os.listdir(csv_dir)):
        if csv_file.endswith(".csv") and csv_file != os.path.basename(resumo_path):
            path = os.path.join(csv_dir, csv_file)
            try:
                df = pd.read_csv(path)
                if len(df) == 0:
                    print(f"🟡 Pulando (vazio): {csv_file}")
                    continue
                sheet_name = os.path.splitext(csv_file)[0][:31]
                df.to_excel(writer, sheet_name=sheet_name, index=False)
            except Exception as e:
                print(f"❗ Erro ao processar {csv_file}: {e}")

print(f"📦 Consolidação finalizada: {xlsx_path}")
EOF

echo "✅ Execução finalizada. Consolidado salvo em: $OUTPUT_XLSX"
