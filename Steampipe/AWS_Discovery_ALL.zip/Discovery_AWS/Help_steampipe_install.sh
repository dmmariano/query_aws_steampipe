#Install

sudo /bin/sh -c "$(curl -fsSL https://steampipe.io/install/steampipe.sh)"
