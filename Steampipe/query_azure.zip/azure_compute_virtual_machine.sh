# .inspect azure_compute_virtual_machine
# +-------------------------------------+------------------+-----------------------------------------------------------+
# | column                              | type             | description                                               |
# +-------------------------------------+------------------+-----------------------------------------------------------+
# | _ctx                                | jsonb            | Steampipe context in JSON form.                           |
# | additional_unattend_content         | jsonb            | Specifies additional base-64 encoded XML formatted inform |
# |                                     |                  | ation that can be included in the Unattend.xml file, whic |
# |                                     |                  | h is used by windows setup.                               |
# | admin_user_name                     | text             | Specifies the name of the administrator account.          |
# | akas                                | jsonb            | Array of globally unique identifier strings (also known a |
# |                                     |                  | s) for the resource.                                      |
# | allow_extension_operations          | boolean          | Specifies whether extension operations should be allowed  |
# |                                     |                  | on the virtual machine.                                   |
# | availability_set_id                 | text             | Specifies the ID of the availability set.                 |
# | billing_profile_max_price           | double precision | Specifies the maximum price you are willing to pay for a  |
# |                                     |                  | Azure Spot VM/VMSS.                                       |
# | boot_diagnostics_enabled            | boolean          | Specifies whether boot diagnostics should be enabled on t |
# |                                     |                  | he Virtual Machine, or not.                               |
# | boot_diagnostics_storage_uri        | text             | Contains the Uri of the storage account to use for placin |
# |                                     |                  | g the console output and screenshot.                      |
# | cloud_environment                   | text             | The Azure Cloud Environment.                              |
# | computer_name                       | text             | Specifies the host OS name of the virtual machine.        |
# | data_disks                          | jsonb            | A list of parameters that are used to add a data disk to  |
# |                                     |                  | a virtual machine.                                        |
# | disable_password_authentication     | boolean          | Specifies whether password authentication should be disab |
# |                                     |                  | led.                                                      |
# | enable_automatic_updates            | boolean          | Indicates whether automatic updates is enabled for the wi |
# |                                     |                  | ndows virtual machine.                                    |
# | eviction_policy                     | text             | Specifies the eviction policy for the Azure Spot virtual  |
# |                                     |                  | machine and Azure Spot scale set.                         |
# | extensions                          | jsonb            | Specifies the details of VM Extensions.                   |
# | guest_configuration_assignments     | jsonb            | Guest configuration assignments for a virtual machine.    |
# | id                                  | text             | The unique id identifying the resource in subscription.   |
# | identity                            | jsonb            | The identity of the virtual machine, if configured.       |
# | image_exact_version                 | text             | Specifies in decimal numbers, the version of platform ima |
# |                                     |                  | ge or marketplace image used to create the virtual machin |
# |                                     |                  | e.                                                        |
# | image_id                            | text             | Specifies the ID of the image to use.                     |
# | image_offer                         | text             | Specifies the offer of the platform image or marketplace  |
# |                                     |                  | image used to create the virtual machine.                 |
# | image_publisher                     | text             | Specifies the publisher of the image to use.              |
# | image_sku                           | text             | Specifies the sku of the image to use.                    |
# | image_version                       | text             | Specifies the version of the platform image or marketplac |
# |                                     |                  | e image used to create the virtual machine.               |
# | linux_configuration_ssh_public_keys | jsonb            | A list of ssh key configuration for a Linux OS            |
# | managed_disk_id                     | text             | Specifies the ID of the managed disk used by the virtual  |
# |                                     |                  | machine.                                                  |
# | name                                | text             | The friendly name that identifies the virtual machine.    |
# | network_interfaces                  | jsonb            | A list of resource Ids for the network interfaces associa |
# |                                     |                  | ted with the virtual machine.                             |
# | os_disk_caching                     | text             | Specifies the caching requirements of the operating syste |
# |                                     |                  | m disk used by the virtual machine.                       |
# | os_disk_create_option               | text             | Specifies how the virtual machine should be created.      |
# | os_disk_name                        | text             | Specifies the name of the operating system disk used by t |
# |                                     |                  | he virtual machine.                                       |
# | os_disk_vhd_uri                     | text             | Specifies the virtual hard disk's uri.                    |
# | os_name                             | text             | The Operating System running on the virtual machine.      |
# | os_type                             | text             | Specifies the type of the OS that is included in the disk |
# |                                     |                  |  if creating a VM from user-image or a specialized VHD.   |
# | os_version                          | text             | The version of Operating System running on the virtual ma |
# |                                     |                  | chine.                                                    |
# | patch_settings                      | jsonb            | Specifies settings related to in-guest patching (KBs).    |
# | power_state                         | text             | Specifies the power state of the VM.                      |
# | priority                            | text             | Specifies the priority for the virtual machine.           |
# | private_ips                         | jsonb            | An array of private ip addesses associated with the vm.   |
# | provision_vm_agent                  | boolean          | Specifies whether virtual machine agent should be provisi |
# |                                     |                  | oned on the virtual machine for linux configuration.      |
# | provision_vm_agent_windows          | boolean          | Specifies whether virtual machine agent should be provisi |
# |                                     |                  | oned on the virtual machine for windows configuration.    |
# | provisioning_state                  | text             | The virtual machine provisioning state.                   |
# | public_ips                          | jsonb            | An array of public ip addesses associated with the vm.    |
# | region                              | text             | The Azure region/location in which the resource is locate |
# |                                     |                  | d.                                                        |
# | require_guest_provision_signal      | boolean          | Specifies whether the guest provision signal is required  |
# |                                     |                  | to infer provision success of the virtual machine.        |
# | resource_group                      | text             | The resource group which holds this resource.             |
# | secrets                             | jsonb            | A list of certificates that should be installed onto the  |
# |                                     |                  | virtual machine.                                          |
# | security_profile                    | jsonb            | Specifies the security related profile settings for the v |
# |                                     |                  | irtual machine.                                           |
# | size                                | text             | Specifies the size of the virtual machine.                |
# | sp_connection_name                  | text             | Steampipe connection name.                                |
# | sp_ctx                              | jsonb            | Steampipe context in JSON form.                           |
# | statuses                            | jsonb            | Specifies the resource status information.                |
# | subscription_id                     | text             | The Azure Subscription ID in which the resource is locate |
# |                                     |                  | d.                                                        |
# | tags                                | jsonb            | A map of tags for the resource.                           |
# | time_zone                           | text             | Specifies the time zone of the virtual machine.           |
# | title                               | text             | Title of the resource.                                    |
# | type                                | text             | The type of the resource in Azure.                        |
# | ultra_ssd_enabled                   | boolean          | Specifies whether managed disks with storage account type |
# |                                     |                  |  UltraSSD_LRS can be added to a virtual machine or virtua |
# |                                     |                  | l machine scale set, or not.                              |
# | vm_id                               | text             | Specifies an unique ID for VM, which is a 128-bits identi |
# |                                     |                  | fier that is encoded and stored in all Azure IaaS VMs SMB |
# |                                     |                  | IOS and can be read using platform BIOS commands.         |
# | win_rm                              | jsonb            | Specifies the windows remote management listeners. This e |
# |                                     |                  | nables remote windows powershell.                         |
# | zones                               | jsonb            | A list of virtual machine zones.                          |
# +-------------------------------------+------------------+-----------------------------------------------------------+

time steampipe query "
SELECT
    subscription_id,
    resource_group,
    region as location,
    vm_id,
    name as instance_name,
    power_state as status,
    type,
    size as shape,
    os_type,
    os_name,
    image_sku,
    image_offer as disk_image,
    os_disk_create_option as os_creation,
    data_disks,
    ultra_ssd_enabled as ultra_ssd,
    tags
FROM
    ${TABLE_PREFIX}azure_compute_virtual_machine
WHERE
    power_state != 'deallocated'
" --output csv >.azure_compute_virtual_machine.tmp 2>&1
