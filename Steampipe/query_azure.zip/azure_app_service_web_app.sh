# .inspect azure_app_service_web_app;
# +--------------------------------+---------+-----------------------------------------------------------------------+
# | column                         | type    | description                                                           |
# +--------------------------------+---------+-----------------------------------------------------------------------+
# | _ctx                           | jsonb   | Steampipe context in JSON form.                                       |
# | akas                           | jsonb   | Array of globally unique identifier strings (also known as) for the r |
# |                                |         | esource.                                                              |
# | auth_settings                  | jsonb   | Describes the Authentication/Authorization settings of an app.        |
# | client_affinity_enabled        | boolean | Specify whether client affinity is enabled.                           |
# | client_cert_enabled            | boolean | Specify whether client certificate authentication is enabled.         |
# | cloud_environment              | text    | The Azure Cloud Environment.                                          |
# | configuration                  | jsonb   | Describes the configuration of an app.                                |
# | default_site_hostname          | text    | Default hostname of the app.                                          |
# | diagnostic_logs_configuration  | jsonb   | Describes the logging configuration of an app.                        |
# | enabled                        | boolean | Specify whether the app is enabled.                                   |
# | host_name_disabled             | boolean | Specify whether the public hostnames of the app is disabled.          |
# | host_names                     | jsonb   | A list of hostnames associated with the app.                          |
# | https_only                     | boolean | Specify whether configuring a web site to accept only https requests. |
# | id                             | text    | Contains ID to identify an app service web app uniquely.              |
# | identity                       | jsonb   | Managed service identity for the resource.                            |
# | kind                           | text    | Contains the kind of the resource.                                    |
# | name                           | text    | The friendly name that identifies the app service web app.            |
# | outbound_ip_addresses          | text    | List of IP addresses that the app uses for outbound connections (e.g. |
# |                                |         |  database access).                                                    |
# | possible_outbound_ip_addresses | text    | List of possible IP addresses that the app uses for outbound connecti |
# |                                |         | ons (e.g. database access).                                           |
# | region                         | text    | The Azure region/location in which the resource is located.           |
# | reserved                       | boolean | Specify whether the app is reserved.                                  |
# | resource_group                 | text    | The resource group which holds this resource.                         |
# | site_config                    | jsonb   | A map of all configuration for the app.                               |
# | sp_connection_name             | text    | Steampipe connection name.                                            |
# | sp_ctx                         | jsonb   | Steampipe context in JSON form.                                       |
# | state                          | text    | Current state of the app.                                             |
# | storage_info_value             | jsonb   | AzureStorageInfoValue azure Files or Blob Storage access information  |
# |                                |         | value for dictionary storage.                                         |
# | subscription_id                | text    | The Azure Subscription ID in which the resource is located.           |
# | tags                           | jsonb   | A map of tags for the resource.                                       |
# | title                          | text    | Title of the resource.                                                |
# | type                           | text    | The resource type of the app service web app.                         |
# | vnet_connection                | jsonb   | Describes the virtual network connection for the app.                 |
# +--------------------------------+---------+-----------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location ,
    name,
    type, 
    kind,
    state,
    reserved,
    site_config,
    tags
from 
    ${TABLE_PREFIX}azure_app_service_web_app
" --output csv 1>azure_app_service_web_app.csv 2>&1
