# > .inspect azure_application_insight;
# +-------------------------------------+--------------------------+---------------------------------------------------+
# | column                              | type                     | description                                       |
# +-------------------------------------+--------------------------+---------------------------------------------------+
# | _ctx                                | jsonb                    | Steampipe context in JSON form.                   |
# | akas                                | jsonb                    | Array of globally unique identifier strings (also |
# |                                     |                          |  known as) for the resource.                      |
# | app_id                              | text                     | Application insights unique id for your Applicati |
# |                                     |                          | on.                                               |
# | application_type                    | jsonb                    | Type of application being monitored.              |
# | cloud_environment                   | text                     | The Azure Cloud Environment.                      |
# | connection_string                   | text                     | Application Insights component connection string. |
# | creation_date                       | timestamp with time zone | Creation date for the Application Insights compon |
# |                                     |                          | ent.                                              |
# | disable_ip_masking                  | boolean                  | Disable IP masking.                               |
# | disable_local_auth                  | boolean                  | Disable Non-AAD based Auth.                       |
# | etag                                | text                     | A unique read-only string that changes whenever t |
# |                                     |                          | he resource is updated.                           |
# | flow_type                           | jsonb                    | Determines what kind of flow this component was c |
# |                                     |                          | reated by.                                        |
# | force_customer_storage_for_profiler | boolean                  | Force users to create their own storage account f |
# |                                     |                          | or profiler and debugger.                         |
# | id                                  | text                     | Contains id to identify the application insight u |
# |                                     |                          | niquely.                                          |
# | immediate_purge_data_on_30_days     | boolean                  | Purge data immediately after 30 days.             |
# | ingestion_mode                      | jsonb                    | Indicates the flow of the ingestion.              |
# | instrumentation_key                 | text                     | Application Insights Instrumentation key.         |
# | kind                                | text                     | The kind of application that this component refer |
# |                                     |                          | s to, used to customize UI.                       |
# | name                                | text                     | The friendly name that identifies the application |
# |                                     |                          |  insight.                                         |
# | private_link_scoped_resources       | jsonb                    | List of linked private link scope resources.      |
# | provisioning_state                  | text                     | Current state of this component.                  |
# | public_network_access_for_ingestion | text                     | The network access type for accessing Application |
# |                                     |                          |  Insights ingestion.                              |
# | public_network_access_for_query     | text                     | The network access type for accessing Application |
# |                                     |                          |  Insights query.                                  |
# | region                              | text                     | The Azure region/location in which the resource i |
# |                                     |                          | s located.                                        |
# | request_source                      | text                     | Describes what tool created this Application Insi |
# |                                     |                          | ghts component.                                   |
# | resource_group                      | text                     | The resource group which holds this resource.     |
# | retention_in_days                   | bigint                   | Retention period in days.                         |
# | sampling_percentage                 | double precision         | Percentage of the data produced by the applicatio |
# |                                     |                          | n being monitored that is being sampled for Appli |
# |                                     |                          | cation Insights telemetry.                        |
# | sp_connection_name                  | text                     | Steampipe connection name.                        |
# | sp_ctx                              | jsonb                    | Steampipe context in JSON form.                   |
# | subscription_id                     | text                     | The Azure Subscription ID in which the resource i |
# |                                     |                          | s located.                                        |
# | tags                                | jsonb                    | A map of tags for the resource.                   |
# | tenant_id                           | text                     | Azure Tenant ID.                                  |
# | title                               | text                     | Title of the resource.                            |
# | type                                | text                     | The resource type of the application insight.     |
# | workspace_resource_id               | text                     | Resource Id of the log analytics workspace to whi |
# |                                     |                          | ch the data will be ingested.                     |
# +-------------------------------------+--------------------------+---------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    application_type,
    ingestion_mode,
    retention_in_days,
    tags
from 
    ${TABLE_PREFIX}azure_application_insight;
" --output csv 1>azure_application_insight.csv 2>&1
