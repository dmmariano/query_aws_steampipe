# .inspect azure_network_watcher
# +--------------------+-------+-------------------------------------------------------------------------------+
# | column             | type  | description                                                                   |
# +--------------------+-------+-------------------------------------------------------------------------------+
# | _ctx               | jsonb | Steampipe context in JSON form.                                               |
# | akas               | jsonb | Array of globally unique identifier strings (also known as) for the resource. |
# | cloud_environment  | text  | The Azure Cloud Environment.                                                  |
# | etag               | text  | An unique read-only string that changes whenever the resource is updated      |
# | id                 | text  | Contains ID to identify a network watcher uniquely                            |
# | name               | text  | The friendly name that identifies the network watcher                         |
# | provisioning_state | text  | The provisioning state of the network watcher resource                        |
# | region             | text  | The Azure region/location in which the resource is located.                   |
# | resource_group     | text  | The resource group which holds this resource.                                 |
# | sp_connection_name | text  | Steampipe connection name.                                                    |
# | sp_ctx             | jsonb | Steampipe context in JSON form.                                               |
# | subscription_id    | text  | The Azure Subscription ID in which the resource is located.                   |
# | tags               | jsonb | A map of tags for the resource.                                               |
# | title              | text  | Title of the resource.                                                        |
# | type               | text  | The resource type of the network watcher                                      |
# +--------------------+-------+-------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id
    resource_group,
    region as location,
    name,
    type,
    tags
from
    ${TABLE_PREFIX}azure_network_watcher;
" --output csv 1>azure_network_watcher.csv 2>&1
