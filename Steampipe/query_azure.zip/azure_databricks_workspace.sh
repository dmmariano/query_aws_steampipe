# .inspect azure_databricks_workspace
# +---------------------------+--------------------------+---------------------------------------------------------+
# | column                    | type                     | description                                             |
# +---------------------------+--------------------------+---------------------------------------------------------+
# | _ctx                      | jsonb                    | Steampipe context in JSON form.                         |
# | akas                      | jsonb                    | Array of globally unique identifier strings (also known |
# |                           |                          |  as) for the resource.                                  |
# | authorizations            | jsonb                    | The workspace provider authorizations.                  |
# | cloud_environment         | text                     | The Azure Cloud Environment.                            |
# | created_by                | jsonb                    | Indicates the Object ID, PUID and Application ID of ent |
# |                           |                          | ity that created the workspace.                         |
# | created_date_time         | timestamp with time zone | Specifies the date and time when the workspace is creat |
# |                           |                          | ed.                                                     |
# | id                        | text                     | Fully qualified resource ID for the resource.           |
# | location                  | text                     | The geo-location where the resource lives.              |
# | managed_resource_group_id | text                     | The managed resource group ID.                          |
# | name                      | text                     | The resource name.                                      |
# | parameters                | jsonb                    | The workspace's custom parameters.                      |
# | provisioning_state        | text                     | The workspace provisioning state.                       |
# | region                    | text                     | The Azure region/location in which the resource is loca |
# |                           |                          | ted.                                                    |
# | resource_group            | text                     | The resource group which holds this resource.           |
# | sku                       | jsonb                    | The SKU of the resource.                                |
# | sp_connection_name        | text                     | Steampipe connection name.                              |
# | sp_ctx                    | jsonb                    | Steampipe context in JSON form.                         |
# | storage_account_identity  | jsonb                    | The details of Managed Identity of Storage Account      |
# | subscription_id           | text                     | The Azure Subscription ID in which the resource is loca |
# |                           |                          | ted.                                                    |
# | tags                      | jsonb                    | A map of tags for the resource.                         |
# | title                     | text                     | Title of the resource.                                  |
# | type                      | text                     | The type of the resource.                               |
# | ui_definition_uri         | text                     | The blob URI where the UI definition file is located.   |
# | updated_by                | jsonb                    | Indicates the Object ID, PUID and Application ID of ent |
# |                           |                          | ity that last updated the workspace.                    |
# | workspace_id              | text                     | The unique identifier of the databricks workspace in da |
# |                           |                          | tabricks control plane.                                 |
# | workspace_url             | text                     | The workspace URL which is of the format 'adb-{workspac |
# |                           |                          | eId}.{random}.azuredatabricks.net'.                     |
# +---------------------------+--------------------------+---------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    sku,
    type,
    location,
    tags
from 
    ${TABLE_PREFIX}azure_databricks_workspace
" --output csv 1>azure_databricks_workspace.csv 2>&1
