# .inspect azure_mysql_flexible_server
# +--------------------------------+--------------------------+----------------------------------------------------+
# | column                         | type                     | description                                        |
# +--------------------------------+--------------------------+----------------------------------------------------+
# | _ctx                           | jsonb                    | Steampipe context in JSON form.                    |
# | administrator_login            | text                     | The administrator's login name of a server.        |
# | akas                           | jsonb                    | Array of globally unique identifier strings (also  |
# |                                |                          | known as) for the resource.                        |
# | availability_zone              | text                     | Availability Zone information of the server.       |
# | backup_retention_days          | bigint                   | Backup retention days for the server.              |
# | cloud_environment              | text                     | The Azure Cloud Environment.                       |
# | create_mode                    | text                     | The mode to create a new server.                   |
# | earliest_restore_date          | timestamp with time zone | Specifies the earliest restore point creation time |
# |                                |                          | .                                                  |
# | flexible_server_configurations | jsonb                    | The server configurations(parameters) details of t |
# |                                |                          | he server.                                         |
# | fully_qualified_domain_name    | text                     | The fully qualified domain name of the server.     |
# | geo_redundant_backup           | text                     | Indicates whether Geo-redundant is enabled, or not |
# |                                |                          |  for server backup.                                |
# | high_availability              | jsonb                    | High availability related properties of a server.  |
# | id                             | text                     | Contains ID to identify a server uniquely.         |
# | location                       | text                     | The server location.                               |
# | maintenance_window             | jsonb                    | Maintenance window of a server.                    |
# | name                           | text                     | The friendly name that identifies the server.      |
# | network                        | jsonb                    | Network related properties of a server.            |
# | public_network_access          | text                     | Whether or not public network access is allowed fo |
# |                                |                          | r this server.                                     |
# | region                         | text                     | The Azure region/location in which the resource is |
# |                                |                          |  located.                                          |
# | replica_capacity               | bigint                   | The maximum number of replicas that a primary serv |
# |                                |                          | er can have.                                       |
# | replication_role               | text                     | The replication role of the server.                |
# | resource_group                 | text                     | The resource group which holds this resource.      |
# | restore_point_in_time          | timestamp with time zone | Restore point creation time (ISO8601 format), spec |
# |                                |                          | ifying the time to restore from.                   |
# | sku_name                       | text                     | The name of the sku.                               |
# | sku_tier                       | text                     | The tier of the particular SKU.                    |
# | source_server_resource_id      | text                     | The source MySQL server id.                        |
# | sp_connection_name             | text                     | Steampipe connection name.                         |
# | sp_ctx                         | jsonb                    | Steampipe context in JSON form.                    |
# | state                          | text                     | The state of the server.                           |
# | storage_auto_grow              | text                     | Indicates whether storage auto grow is enabled, or |
# |                                |                          |  not.                                              |
# | storage_iops                   | bigint                   | Storage IOPS for a server.                         |
# | storage_size_gb                | bigint                   | Indicates max storage allowed for a server.        |
# | storage_sku                    | text                     | The sku name of the server storage.                |
# | subscription_id                | text                     | The Azure Subscription ID in which the resource is |
# |                                |                          |  located.                                          |
# | system_data                    | jsonb                    | The system metadata relating to this server.       |
# | tags                           | jsonb                    | A map of tags for the resource.                    |
# | title                          | text                     | Title of the resource.                             |
# | type                           | text                     | The resource type of the server.                   |
# | version                        | text                     | Specifies the version of the server.               |
# +--------------------------------+--------------------------+----------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,

from 
    ${TABLE_PREFIX}azure_log_analytics_workspace
" --output csv 1>azure_log_analytics_workspace.csv 2>&1
