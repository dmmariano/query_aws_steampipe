# .inspect azure_mysql_server
# +------------------------------+--------------------------+------------------------------------------------------+
# | column                       | type                     | description                                          |
# +------------------------------+--------------------------+------------------------------------------------------+
# | _ctx                         | jsonb                    | Steampipe context in JSON form.                      |
# | administrator_login          | text                     | Specifies the username of the administrator for this |
# |                              |                          |  server.                                             |
# | akas                         | jsonb                    | Array of globally unique identifier strings (also kn |
# |                              |                          | own as) for the resource.                            |
# | backup_retention_days        | bigint                   | Backup retention days for the server.                |
# | byok_enforcement             | text                     | Status showing whether the server data encryption is |
# |                              |                          |  enabled with customer-managed keys.                 |
# | cloud_environment            | text                     | The Azure Cloud Environment.                         |
# | earliest_restore_date        | timestamp with time zone | Specifies the earliest restore point creation time.  |
# | fully_qualified_domain_name  | text                     | The fully qualified domain name of the server.       |
# | geo_redundant_backup         | text                     | Indicates whether Geo-redundant is enabled, or not f |
# |                              |                          | or server backup.                                    |
# | id                           | text                     | Contains ID to identify a server uniquely.           |
# | infrastructure_encryption    | text                     | Status showing whether the server enabled infrastruc |
# |                              |                          | ture encryption. Possible values include: 'Enabled', |
# |                              |                          |  'Disabled'.                                         |
# | location                     | text                     | The resource location.                               |
# | master_server_id             | text                     | The master server id of a replica server.            |
# | minimal_tls_version          | text                     | Enforce a minimal Tls version for the server. Possib |
# |                              |                          | le values include: 'TLS10', 'TLS11', 'TLS12', 'TLSEn |
# |                              |                          | forcementDisabled'.                                  |
# | name                         | text                     | The friendly name that identifies the server.        |
# | private_endpoint_connections | jsonb                    | A list of private endpoint connections on a server.  |
# | public_network_access        | text                     | Indicates whether or not public network access is al |
# |                              |                          | lowed for this server. Value is optional but if pass |
# |                              |                          | ed in, must be 'Enabled' or 'Disabled'. Possible val |
# |                              |                          | ues include: 'Enabled', 'Disabled'.                  |
# | region                       | text                     | The Azure region/location in which the resource is l |
# |                              |                          | ocated.                                              |
# | replica_capacity             | bigint                   | The maximum number of replicas that a master server  |
# |                              |                          | can have.                                            |
# | replication_role             | text                     | The replication role of the server.                  |
# | resource_group               | text                     | The resource group which holds this resource.        |
# | server_configurations        | jsonb                    | The server configurations(parameters) details of the |
# |                              |                          |  server.                                             |
# | server_keys                  | jsonb                    | The server keys of the server.                       |
# | server_security_alert_policy | jsonb                    | Security alert policy associated with the MySQL Serv |
# |                              |                          | er.                                                  |
# | sku_capacity                 | bigint                   | The scale up/out capacity, representing server's com |
# |                              |                          | pute units.                                          |
# | sku_family                   | text                     | The family of hardware.                              |
# | sku_name                     | text                     | The name of the sku. For example: 'B_Gen4_1', 'GP_Ge |
# |                              |                          | n5_8'.                                               |
# | sku_size                     | text                     | The size code, to be interpreted by resource as appr |
# |                              |                          | opriate.                                             |
# | sku_tier                     | text                     | The tier of the particular SKU. Possible values incl |
# |                              |                          | ude: 'Basic', 'GeneralPurpose', 'MemoryOptimized'.   |
# | sp_connection_name           | text                     | Steampipe connection name.                           |
# | sp_ctx                       | jsonb                    | Steampipe context in JSON form.                      |
# | ssl_enforcement              | text                     | Enable ssl enforcement or not when connect to server |
# |                              |                          | . Possible values include: 'Enabled', 'Disabled'.    |
# | state                        | text                     | The state of the server.                             |
# | storage_auto_grow            | text                     | Indicates whether storage auto grow is enabled, or n |
# |                              |                          | ot.                                                  |
# | storage_mb                   | bigint                   | Indicates max storage allowed for a server.          |
# | subscription_id              | text                     | The Azure Subscription ID in which the resource is l |
# |                              |                          | ocated.                                              |
# | tags                         | jsonb                    | A map of tags for the resource.                      |
# | title                        | text                     | Title of the resource.                               |
# | type                         | text                     | The resource type of the server.                     |
# | user_visible_state           | text                     | A state of a server that is visible to user. Possibl |
# |                              |                          | e values include: 'Ready', 'Dropping', 'Disabled', ' |
# |                              |                          | Inaccessible'.                                       |
# | version                      | text                     | Specifies the version of the server.                 |
# | vnet_rules                   | jsonb                    | Rules represented by VNET.                           |
# +------------------------------+--------------------------+------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    version,
    backup_retention_days,
    sku_capacity,
    sku_family,
    sku_name,
    sku_size,
    sku_tier,
    storage_auto_grow,
    storage_mb,
    tags
from 
    ${TABLE_PREFIX}azure_mysql_server
" --output csv 1>azure_mysql_server.csv 2>&1