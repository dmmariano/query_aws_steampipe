# .inspect azure_recovery_services_vault;
# +------------------------------------------+-------+---------------------------------------------------------------+
# | column                                   | type  | description                                                   |
# +------------------------------------------+-------+---------------------------------------------------------------+
# | _ctx                                     | jsonb | Steampipe context in JSON form.                               |
# | akas                                     | jsonb | Array of globally unique identifier strings (also known as) f |
# |                                          |       | or the resource.                                              |
# | cloud_environment                        | text  | The Azure Cloud Environment.                                  |
# | diagnostic_settings                      | jsonb | A list of active diagnostic settings for the recovery service |
# |                                          |       | s vault.                                                      |
# | etag                                     | text  | An unique read-only string that changes whenever the resource |
# |                                          |       |  is updated.                                                  |
# | id                                       | text  | The resource identifier.                                      |
# | identity                                 | jsonb | Managed service identity of the recovery services vault.      |
# | name                                     | text  | The resource name.                                            |
# | private_endpoint_connections             | jsonb | List of private endpoint connections of the recovery services |
# |                                          |       |  vault.                                                       |
# | private_endpoint_state_for_backup        | text  | Private endpoint state for backup of the recovery services va |
# |                                          |       | ult.                                                          |
# | private_endpoint_state_for_site_recovery | text  | Private endpoint state for site recovery of the recovery serv |
# |                                          |       | ices vault.                                                   |
# | provisioning_state                       | text  | The provisioning state of the recovery services vault.        |
# | region                                   | text  | The Azure region/location in which the resource is located.   |
# | resource_group                           | text  | The resource group which holds this resource.                 |
# | sku_name                                 | text  | The sku name of the recovery services vault.                  |
# | sp_connection_name                       | text  | Steampipe connection name.                                    |
# | sp_ctx                                   | jsonb | Steampipe context in JSON form.                               |
# | subscription_id                          | text  | The Azure Subscription ID in which the resource is located.   |
# | tags                                     | jsonb | A map of tags for the resource.                               |
# | title                                    | text  | Title of the resource.                                        |
# | type                                     | text  | The resource type.                                            |
# | upgrade_details                          | jsonb | Upgrade details properties of the recovery services vault.    |
# +------------------------------------------+-------+---------------------------------------------------------------+

time steampipe query "
select
    subscription_id
    resource_group,
    region as location,
    name,
    type,
    sku_name,
    tags
from
    ${TABLE_PREFIX}azure_recovery_services_vault;
" --output csv 1>azure_recovery_services_vault.csv 2>&1