# .inspect azure_monitor_log_profile;
# +---------------------+-------+------------------------------------------------------------------------------------+
# | column              | type  | description                                                                        |
# +---------------------+-------+------------------------------------------------------------------------------------+
# | _ctx                | jsonb | Steampipe context in JSON form.                                                    |
# | akas                | text  | Array of globally unique identifier strings (also known as) for the resource.      |
# | categories          | jsonb | The categories of the logs. These categories are created as is convenient to the u |
# |                     |       | ser.                                                                               |
# | cloud_environment   | text  | The Azure Cloud Environment.                                                       |
# | id                  | text  | Azure resource Id.                                                                 |
# | location            | text  | The resource location.                                                             |
# | locations           | jsonb | List of regions for which Activity Log events should be stored or streamed. It is  |
# |                     |       | a comma separated list of valid ARM locations including the 'global' location.     |
# | name                | text  | Azure resource name.                                                               |
# | retention_policy    | jsonb | The retention policy for the events in the log.                                    |
# | service_bus_rule_id | text  | The service bus rule ID of the service bus namespace in which you would like to ha |
# |                     |       | ve Event Hubs created for streaming the Activity Log.                              |
# | sp_connection_name  | text  | Steampipe connection name.                                                         |
# | sp_ctx              | jsonb | Steampipe context in JSON form.                                                    |
# | storage_account_id  | text  | The resource id of the storage account to which you would like to send the Activit |
# |                     |       | y Log.                                                                             |
# | subscription_id     | text  | The Azure Subscription ID in which the resource is located.                        |
# | tags                | jsonb | A map of tags for the resource.                                                    |
# | title               | text  | Title of the resource.                                                             |
# | type                | text  | Azure resource type.                                                               |
# +---------------------+-------+------------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    locations as location,
    name,
    type,
    retention_policy,
    tags
from 
    ${TABLE_PREFIX}azure_monitor_log_profile;
" --output csv 1>azure_monitor_log_profile.csv 2>&1
