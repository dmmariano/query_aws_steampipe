# .inspect azure_app_service_plan;
# +------------------------------+---------+---------------------------------------------------------------------------------------+
# | column                       | type    | description                                                                           |
# +------------------------------+---------+---------------------------------------------------------------------------------------+
# | _ctx                         | jsonb   | Steampipe context in JSON form.                                                       |
# | akas                         | jsonb   | Array of globally unique identifier strings (also known as) for the resource.         |
# | apps                         | jsonb   | Site a web app, a mobile app backend, or an API app.                                  |
# | cloud_environment            | text    | The Azure Cloud Environment.                                                          |
# | hyper_v                      | boolean | Specify whether resource is Hyper-V container app service plan                        |
# | id                           | text    | Contains ID to identify an app service plan uniquely                                  |
# | is_spot                      | boolean | Specify whether this App Service Plan owns spot instances, or not                     |
# | is_xenon                     | boolean | Specify whether resource is Hyper-V container app service plan                        |
# | kind                         | text    | Contains the kind of the resource                                                     |
# | maximum_elastic_worker_count | bigint  | Maximum number of total workers allowed for this ElasticScaleEnabled App Service Plan |
# | maximum_number_of_workers    | bigint  | Maximum number of instances that can be assigned to this App Service plan             |
# | name                         | text    | The friendly name that identifies the app service plan                                |
# | per_site_scaling             | boolean | Specify whether apps assigned to this App Service plan can be scaled independently    |
# | provisioning_state           | text    | Provisioning state of the App Service Environment                                     |
# | region                       | text    | The Azure region/location in which the resource is located.                           |
# | reserved                     | boolean | Specify whether the resource is Linux app service plan, or not                        |
# | resource_group               | text    | The resource group which holds this resource.                                         |
# | sku_capacity                 | bigint  | Current number of instances assigned to the resource.                                 |
# | sku_family                   | text    | Family code of the resource SKU                                                       |
# | sku_name                     | text    | Name of the resource SKU                                                              |
# | sku_size                     | text    | Size specifier of the resource SKU                                                    |
# | sku_tier                     | text    | Service tier of the resource SKU                                                      |
# | sp_connection_name           | text    | Steampipe connection name.                                                            |
# | sp_ctx                       | jsonb   | Steampipe context in JSON form.                                                       |
# | status                       | text    | App Service plan status                                                               |
# | subscription_id              | text    | The Azure Subscription ID in which the resource is located.                           |
# | tags                         | jsonb   | A map of tags for the resource.                                                       |
# | title                        | text    | Title of the resource.                                                                |
# | type                         | text    | The resource type of the app service plan                                             |
# +------------------------------+---------+---------------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    type,
    name,
    kind,
    status,
    hyper_v,
    is_spot,
    is_xenon,
    maximum_elastic_worker_count,
    maximum_number_of_workers,
    reserved,
    sku_capacity,
    sku_family,
    sku_name,
    sku_size,
    sku_tier,
    tags
from 
    ${TABLE_PREFIX}azure_app_service_plan
" --output csv 1>azure_app_service_plan.csv 2>&1
