# > .inspect azure_application_gateway
# +----------------------------------------+---------+-------------------------------------------------------------+
# | column                                 | type    | description                                                 |
# +----------------------------------------+---------+-------------------------------------------------------------+
# | _ctx                                   | jsonb   | Steampipe context in JSON form.                             |
# | akas                                   | jsonb   | Array of globally unique identifier strings (also known as) |
# |                                        |         |  for the resource.                                          |
# | authentication_certificates            | jsonb   | Authentication certificates of the application gateway.     |
# | autoscale_configuration                | jsonb   | Autoscale Configuration of the application gateway.         |
# | backend_address_pools                  | jsonb   | Backend address pool of the application gateway.            |
# | backend_http_settings_collection       | jsonb   | Backend http settings of the application gateway.           |
# | cloud_environment                      | text    | The Azure Cloud Environment.                                |
# | custom_error_configurations            | jsonb   | Custom error configurations of the application gateway.     |
# | diagnostic_settings                    | jsonb   | A list of active diagnostic settings for the application ga |
# |                                        |         | teway.                                                      |
# | enable_fips                            | boolean | Whether FIPS is enabled on the application gateway.         |
# | enable_http2                           | boolean | Whether HTTP2 is enabled on the application gateway.        |
# | etag                                   | text    | A unique read-only string that changes whenever the resourc |
# |                                        |         | e is updated.                                               |
# | firewall_policy                        | jsonb   | Reference to the FirewallPolicy resource.                   |
# | force_firewall_policy_association      | boolean | If true, associates a firewall policy with an application g |
# |                                        |         | ateway regardless whether the policy differs from the WAF c |
# |                                        |         | onfiguration.                                               |
# | frontend_ip_configurations             | jsonb   | Frontend IP addresses of the application gateway.           |
# | frontend_ports                         | jsonb   | Frontend ports of the application gateway.                  |
# | gateway_ip_configurations              | jsonb   | Subnets of the application gateway.                         |
# | http_listeners                         | jsonb   | Http listeners of the application gateway.                  |
# | id                                     | text    | The resource ID.                                            |
# | identity                               | jsonb   | The identity of the application gateway, if configured.     |
# | name                                   | text    | The resource name.                                          |
# | operational_state                      | text    | Operational state of the application gateway. Possible valu |
# |                                        |         | es include: 'Stopped', 'Starting', 'Running', 'Stopping'.   |
# | private_endpoint_connections           | jsonb   | Private endpoint connections on application gateway.        |
# | private_link_configurations            | jsonb   | PrivateLink configurations on application gateway.          |
# | probes                                 | jsonb   | Probes of the application gateway.                          |
# | provisioning_state                     | text    | The provisioning state of the application gateway. Possible |
# |                                        |         |  values include: 'Succeeded', 'Updating', 'Deleting', 'Fail |
# |                                        |         | ed'.                                                        |
# | redirect_configurations                | jsonb   | Redirect configurations of the application gateway.         |
# | region                                 | text    | The Azure region/location in which the resource is located. |
# | request_routing_rules                  | jsonb   | Request routing rules of the application gateway.           |
# | resource_group                         | text    | The resource group which holds this resource.               |
# | resource_guid                          | text    | The resource GUID property of the application gateway.      |
# | rewrite_rule_sets                      | jsonb   | Rewrite rules for the application gateway.                  |
# | sku                                    | jsonb   | SKU of the application gateway.                             |
# | sp_connection_name                     | text    | Steampipe connection name.                                  |
# | sp_ctx                                 | jsonb   | Steampipe context in JSON form.                             |
# | ssl_certificates                       | jsonb   | SSL certificates of the application gateway.                |
# | ssl_policy                             | jsonb   | SSL policy of the application gateway.                      |
# | ssl_profiles                           | jsonb   | SSL profiles of the application gateway.                    |
# | subscription_id                        | text    | The Azure Subscription ID in which the resource is located. |
# | tags                                   | jsonb   | A map of tags for the resource.                             |
# | title                                  | text    | Title of the resource.                                      |
# | trusted_client_certificates            | jsonb   | Trusted client certificates of the application gateway.     |
# | trusted_root_certificates              | jsonb   | Trusted root certificates of the application gateway.       |
# | type                                   | text    | The resource type.                                          |
# | url_path_maps                          | jsonb   | URL path map of the application gateway.                    |
# | web_application_firewall_configuration | jsonb   | Web application firewall configuration of the application g |
# |                                        |         | ateway.                                                     |
# | zones                                  | jsonb   | A list of availability zones denoting where the resource ne |
# |                                        |         | eds to come from.                                           |
# +----------------------------------------+---------+-------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    sku,
    tags
from 
    ${TABLE_PREFIX}azure_application_gateway
" --output csv 1>azure_application_gateway.csv 2>&1
