# .inspect azure_private_dns_zone
# +-------------------------------------------------------+--------+-------------------------------------------------+
# | column                                                | type   | description                                     |
# +-------------------------------------------------------+--------+-------------------------------------------------+
# | _ctx                                                  | jsonb  | Steampipe context in JSON form.                 |
# | akas                                                  | jsonb  | Array of globally unique identifier strings (al |
# |                                                       |        | so known as) for the resource.                  |
# | cloud_environment                                     | text   | The Azure Cloud Environment.                    |
# | etag                                                  | text   | An unique read-only string that changes wheneve |
# |                                                       |        | r the resource is updated.                      |
# | id                                                    | text   | Contains ID to identify a Private DNS zone uniq |
# |                                                       |        | uely.                                           |
# | max_number_of_record_sets                             | bigint | The maximum number of record sets that can be c |
# |                                                       |        | reated in this Private DNS zone.                |
# | max_number_of_virtual_network_links                   | bigint | The maximum number of virtual networks that can |
# |                                                       |        |  be linked to this Private DNS zone.            |
# | max_number_of_virtual_network_links_with_registration | bigint | The maximum number of virtual networks that can |
# |                                                       |        |  be linked to this Private DNS zone with regist |
# |                                                       |        | ration enabled.                                 |
# | name                                                  | text   | The friendly name that identifies the Private D |
# |                                                       |        | NS zone.                                        |
# | number_of_record_sets                                 | bigint | The current number of record sets in this Priva |
# |                                                       |        | te DNS zone.                                    |
# | number_of_virtual_network_links                       | bigint | The current number of virtual networks that are |
# |                                                       |        |  linked to this Private DNS zone.               |
# | number_of_virtual_network_links_with_registration     | bigint | The current number of virtual networks that are |
# |                                                       |        |  linked to this Private DNS zone with registrat |
# |                                                       |        | ion enabled.                                    |
# | provisioning_state                                    | text   | The provisioning state of the resource. Possibl |
# |                                                       |        | e values include: `Creating`, `Updating`, `Dele |
# |                                                       |        | ting`, `Succeeded`, `Failed`, `Canceled`.       |
# | region                                                | text   | The Azure region/location in which the resource |
# |                                                       |        |  is located.                                    |
# | resource_group                                        | text   | The resource group which holds this resource.   |
# | sp_connection_name                                    | text   | Steampipe connection name.                      |
# | sp_ctx                                                | jsonb  | Steampipe context in JSON form.                 |
# | subscription_id                                       | text   | The Azure Subscription ID in which the resource |
# |                                                       |        |  is located.                                    |
# | tags                                                  | jsonb  | A map of tags for the resource.                 |
# | title                                                 | text   | Title of the resource.                          |
# | type                                                  | text   | The resource type of the Private DNS zone.      |
# +-------------------------------------------------------+--------+-------------------------------------------------+

time steampipe query "
select
    subscription_id
    resource_group,
    region as location,
    name,
    type,
    number_of_record_sets
from
    ${TABLE_PREFIX}azure_private_dns_zone;
" --output csv 1>azure_private_dns_zone.csv 2>&1