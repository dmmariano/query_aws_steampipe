# .inspect azure_api_management;
# +--------------------------------------------------+--------------------------+----------------------------------------+
# | column                                           | type                     | description                            |
# +--------------------------------------------------+--------------------------+----------------------------------------+
# | _ctx                                             | jsonb                    | Steampipe context in JSON form.        |
# | additional_locations                             | jsonb                    | Additional datacenter locations of the |
# |                                                  |                          |  API management service.               |
# | akas                                             | jsonb                    | Array of globally unique identifier st |
# |                                                  |                          | rings (also known as) for the resource |
# |                                                  |                          | .                                      |
# | api_version_constraint                           | jsonb                    | Control plane APIs version constraint  |
# |                                                  |                          | for the API management service.        |
# | certificates                                     | jsonb                    | List of certificates that need to be i |
# |                                                  |                          | nstalled in the API management service |
# |                                                  |                          | .                                      |
# | cloud_environment                                | text                     | The Azure Cloud Environment.           |
# | created_at_utc                                   | timestamp with time zone | Creation UTC date of the API managemen |
# |                                                  |                          | t service.                             |
# | custom_properties                                | jsonb                    | Custom properties of the API managemen |
# |                                                  |                          | t service.                             |
# | developer_portal_url                             | text                     | Developer Portal endpoint URL of the A |
# |                                                  |                          | PI management service.                 |
# | diagnostic_settings                              | jsonb                    | A list of active diagnostic settings f |
# |                                                  |                          | or the API management service.         |
# | disable_gateway                                  | boolean                  | Property only valid for an API managem |
# |                                                  |                          | ent service deployed in multiple locat |
# |                                                  |                          | ions. This can be used to disable the  |
# |                                                  |                          | gateway in master region.              |
# | enable_client_certificate                        | boolean                  | Property only meant to be used for Con |
# |                                                  |                          | sumption SKU Service. This enforces a  |
# |                                                  |                          | client certificate to be presented on  |
# |                                                  |                          | each request to the gateway. This also |
# |                                                  |                          |  enables the ability to authenticate t |
# |                                                  |                          | he certificate in the policy on the ga |
# |                                                  |                          | teway.                                 |
# | etag                                             | text                     | An unique read-only string that change |
# |                                                  |                          | s whenever the resource is updated.    |
# | gateway_regional_url                             | text                     | Gateway URL of the API management serv |
# |                                                  |                          | ice in the default region.             |
# | gateway_url                                      | text                     | Gateway URL of the API management serv |
# |                                                  |                          | ice.                                   |
# | host_name_configurations                         | jsonb                    | Custom hostname configuration of the A |
# |                                                  |                          | PI management service.                 |
# | id                                               | text                     | Contains ID to identify an API managem |
# |                                                  |                          | ent service uniquely.                  |
# | identity_principal_id                            | text                     | The principal id of the identity.      |
# | identity_tenant_id                               | text                     | The client tenant id of the identity.  |
# | identity_type                                    | text                     | The type of identity used for the reso |
# |                                                  |                          | urce.                                  |
# | identity_user_assigned_identities                | jsonb                    | The list of user identities associated |
# |                                                  |                          |  with the resource.                    |
# | management_api_url                               | text                     | Management API endpoint URL of the API |
# |                                                  |                          |  management service.                   |
# | name                                             | text                     | A friendly name that identifies an API |
# |                                                  |                          |  management service.                   |
# | notification_sender_email                        | text                     | Email address from which the notificat |
# |                                                  |                          | ion will be sent.                      |
# | portal_url                                       | text                     | Publisher portal endpoint URL of the A |
# |                                                  |                          | PI management service.                 |
# | private_ip_addresses                             | jsonb                    | Private static load balanced IP addres |
# |                                                  |                          | ses of the API management service in p |
# |                                                  |                          | rimary region which is deployed in an  |
# |                                                  |                          | internal virtual network. Available on |
# |                                                  |                          | ly for 'Basic', 'Standard', 'Premium'  |
# |                                                  |                          | and 'Isolated' SKU.                    |
# | provisioning_state                               | text                     | The current provisioning state of the  |
# |                                                  |                          | API management service. Possible value |
# |                                                  |                          | s include: 'Created', 'Activating', 'S |
# |                                                  |                          | ucceeded', 'Updating', 'Failed', 'Stop |
# |                                                  |                          | ped', 'Terminating', 'TerminationFaile |
# |                                                  |                          | d', 'Deleted'.                         |
# | public_ip_addresses                              | jsonb                    | Public static load balanced IP address |
# |                                                  |                          | es of the API management service in pr |
# |                                                  |                          | imary region. Available only for 'Basi |
# |                                                  |                          | c', 'Standard', 'Premium' and 'Isolate |
# |                                                  |                          | d' SKU.                                |
# | publisher_email                                  | text                     | Publisher email of the API management  |
# |                                                  |                          | service.                               |
# | publisher_name                                   | text                     | Publisher name of the API management s |
# |                                                  |                          | ervice.                                |
# | region                                           | text                     | The Azure region/location in which the |
# |                                                  |                          |  resource is located.                  |
# | resource_group                                   | text                     | The resource group which holds this re |
# |                                                  |                          | source.                                |
# | restore                                          | boolean                  | Undelete API management service if it  |
# |                                                  |                          | was previously soft-deleted.           |
# | scm_url                                          | text                     | SCM endpoint URL of the API management |
# |                                                  |                          |  service.                              |
# | sku_capacity                                     | bigint                   | Capacity of the SKU (number of deploye |
# |                                                  |                          | d units of the SKU)                    |
# | sku_name                                         | text                     | Name of the Sku                        |
# | sp_connection_name                               | text                     | Steampipe connection name.             |
# | sp_ctx                                           | jsonb                    | Steampipe context in JSON form.        |
# | subscription_id                                  | text                     | The Azure Subscription ID in which the |
# |                                                  |                          |  resource is located.                  |
# | tags                                             | jsonb                    | A map of tags for the resource.        |
# | target_provisioning_state                        | text                     | The provisioning state of the API mana |
# |                                                  |                          | gement service, which is targeted by t |
# |                                                  |                          | he long running operation started on t |
# |                                                  |                          | he service.                            |
# | title                                            | text                     | Title of the resource.                 |
# | type                                             | text                     | Type of the resource.                  |
# | virtual_network_configuration_id                 | text                     | The virtual network ID.                |
# | virtual_network_configuration_subnet_name        | text                     | The name of the subnet.                |
# | virtual_network_configuration_subnet_resource_id | text                     | The full resource ID of a subnet in a  |
# |                                                  |                          | virtual network to deploy the API Mana |
# |                                                  |                          | gement service in.                     |
# | virtual_network_type                             | text                     | The type of VPN in which API managemen |
# |                                                  |                          | t service needs to be configured in. N |
# |                                                  |                          | one (Default Value) means the API mana |
# |                                                  |                          | gement service is not part of any Virt |
# |                                                  |                          | ual Network, External means the API ma |
# |                                                  |                          | nagement deployment is set up inside a |
# |                                                  |                          |  Virtual Network having an Internet Fa |
# |                                                  |                          | cing Endpoint, and Internal means that |
# |                                                  |                          |  API management deployment is setup in |
# |                                                  |                          | side a Virtual Network having an Intra |
# |                                                  |                          | net Facing Endpoint only. Possible val |
# |                                                  |                          | ues include: 'None', 'External', 'Inte |
# |                                                  |                          | rnal'                                  |
# | zones                                            | jsonb                    | A list of availability zones denoting  |
# |                                                  |                          | where the resource needs to come from. |
# +--------------------------------------------------+--------------------------+----------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    type,
    name,
    publisher_name,
    sku_capacity,
    sku_name,
    tags
from 
    ${TABLE_PREFIX}azure_api_management
" --output csv 1>azure_api_management.csv 2>&1
