# .inspect azure_redis_cache
# +------------------------------+---------+---------------------------------------------------------------------------------------------------------------------------------+
# | column                       | type    | description                                                                                                                     |
# +------------------------------+---------+---------------------------------------------------------------------------------------------------------------------------------+
# | _ctx                         | jsonb   | Steampipe context in JSON form.                                                                                                 |
# | access_keys                  | jsonb   | The keys of the Redis cache.                                                                                                    |
# | akas                         | jsonb   | Array of globally unique identifier strings (also known as) for the resource.                                                   |
# | cloud_environment            | text    | The Azure Cloud Environment.                                                                                                    |
# | enable_non_ssl_port          | boolean | Specifies whether the non-ssl Redis server port (6379) is enabled.                                                              |
# | host_name                    | text    | Specifies the name of the redis host.                                                                                           |
# | id                           | text    | The unique id identifying the resource in subscription.                                                                         |
# | instances                    | jsonb   | A list of the Redis instances associated with the cache.                                                                        |
# | linked_servers               | jsonb   | A list of the linked servers associated with the cache.                                                                         |
# | minimum_tls_version          | text    | Specifies the TLS version requires to connect.                                                                                  |
# | name                         | text    | The name of the resource.                                                                                                       |
# | port                         | bigint  | Specifies the redis non-SSL port.                                                                                               |
# | private_endpoint_connections | jsonb   | A list of private endpoint connection associated with the specified redis cache.                                                |
# | provisioning_state           | text    | The provisioning state of the redis instance at the time the operation was called. Valid values are: 'Creating', 'Deleting', 'D |
# |                              |         | isabled', 'Failed', 'Linking', 'Provisioning', 'RecoveringScaleFailure', 'Scaling', 'Succeeded', 'Unlinking', 'Unprovisioning', |
# |                              |         |  and 'Updating'.                                                                                                                |
# | public_network_access        | text    | Indicates whether or not public endpoint access is allowed for this cache. Valid values are: 'Enabled', 'Disabled'.             |
# | redis_configuration          | jsonb   | Describes the redis cache configuration.                                                                                        |
# | redis_version                | text    | Specifies the version.                                                                                                          |
# | region                       | text    | The Azure region/location in which the resource is located.                                                                     |
# | replicas_per_master          | bigint  | The number of replicas to be created per master.                                                                                |
# | resource_group               | text    | The resource group which holds this resource.                                                                                   |
# | shard_count                  | bigint  | The number of shards to be created on a premium cluster cache.                                                                  |
# | sku_capacity                 | bigint  | The size of the Redis cache to deploy.                                                                                          |
# | sku_family                   | text    | The SKU family to use.                                                                                                          |
# | sku_name                     | text    | The type of Redis cache to deploy.                                                                                              |
# | sp_connection_name           | text    | Steampipe connection name.                                                                                                      |
# | sp_ctx                       | jsonb   | Steampipe context in JSON form.                                                                                                 |
# | ssl_port                     | bigint  | Specifies the redis SSL port.                                                                                                   |
# | static_ip                    | inet    | Specifies the statis IP address. Required when deploying a Redis cache inside an existing Azure Virtual Network.                |
# | subnet_id                    | text    | The full resource ID of a subnet in a virtual network to deploy the Redis cache in.                                             |
# | subscription_id              | text    | The Azure Subscription ID in which the resource is located.                                                                     |
# | tags                         | jsonb   | A map of tags for the resource.                                                                                                 |
# | tenant_settings              | jsonb   | A dictionary of tenant settings.                                                                                                |
# | title                        | text    | Title of the resource.                                                                                                          |
# | type                         | text    | The type of the resource.                                                                                                       |
# | zones                        | jsonb   | A list of availability zones denoting where the resource needs to come from.                                                    |
# +------------------------------+---------+---------------------------------------------------------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    redis_version,
    instances,
    sku_name,
    sku_capacity,
    sku_family,
    shard_count,
    tags
from
    ${TABLE_PREFIX}azure_redis_cache;
" --output csv 1>azure_redis_cache.csv 2>&1