# .inspect azure_log_analytics_workspace;
# +---------------------------------------------------+--------------------------+-----------------------------------+
# | column                                            | type                     | description                       |
# +---------------------------------------------------+--------------------------+-----------------------------------+
# | _ctx                                              | jsonb                    | Steampipe context in JSON form.   |
# | akas                                              | jsonb                    | The list of globally unique ident |
# |                                                   |                          | ifier strings (also known as) for |
# |                                                   |                          |  the resource.                    |
# | cloud_environment                                 | text                     | The Azure Cloud Environment.      |
# | cluster_resource_id                               | text                     | Dedicated LA cluster resourceId t |
# |                                                   |                          | hat is linked to the workspaces.  |
# | created_date                                      | timestamp with time zone | Workspace creation date.          |
# | customer_id                                       | text                     | Represents the ID associated with |
# |                                                   |                          |  the workspace.                   |
# | disable_local_auth                                | boolean                  | Disable Non-AAD based Auth.       |
# | enable_data_export                                | boolean                  | Flag that indicates if data shoul |
# |                                                   |                          | d be exported.                    |
# | enable_log_access_using_only_resource_permissions | boolean                  | Flag that indicates which permiss |
# |                                                   |                          | ion to use - resource or workspac |
# |                                                   |                          | e or both.                        |
# | force_cmk_for_query                               | boolean                  | Indicates whether customer manage |
# |                                                   |                          | d storage is mandatory for query  |
# |                                                   |                          | management.                       |
# | id                                                | text                     | Contains the unique ID to identif |
# |                                                   |                          | y the Log Analytics workspace.    |
# | immediate_purge_data_on_30_days                   | boolean                  | Flag that describes if we want to |
# |                                                   |                          |  remove the data after 30 days.   |
# | location                                          | text                     | The location of the Log Analytics |
# |                                                   |                          |  workspace.                       |
# | modified_date                                     | timestamp with time zone | Workspace modification date.      |
# | name                                              | text                     | The friendly name that identifies |
# |                                                   |                          |  the Log Analytics workspace.     |
# | private_link_scoped_resources                     | jsonb                    | List of linked private link scope |
# |                                                   |                          |  resources.                       |
# | provisioning_state                                | text                     | The provisioning state of the Log |
# |                                                   |                          |  Analytics workspace.             |
# | public_network_access_for_ingestion               | text                     | The network access type for acces |
# |                                                   |                          | sing Log Analytics ingestion.     |
# | public_network_access_for_query                   | text                     | The network access type for acces |
# |                                                   |                          | sing Log Analytics query.         |
# | region                                            | text                     | The region of the Log Analytics w |
# |                                                   |                          | orkspace.                         |
# | resource_group                                    | text                     | The resource group of the Log Ana |
# |                                                   |                          | lytics workspace.                 |
# | retention_in_days                                 | bigint                   | The retention period for the Log  |
# |                                                   |                          | Analytics workspace data in days. |
# | sku                                               | jsonb                    | The SKU (pricing level) of the Lo |
# |                                                   |                          | g Analytics workspace.            |
# | sp_connection_name                                | text                     | Steampipe connection name.        |
# | sp_ctx                                            | jsonb                    | Steampipe context in JSON form.   |
# | subscription_id                                   | text                     | The Azure Subscription ID in whic |
# |                                                   |                          | h the resource is located.        |
# | tags                                              | jsonb                    | The tags assigned to the Log Anal |
# |                                                   |                          | ytics workspace.                  |
# | title                                             | text                     | The title of the Log Analytics wo |
# |                                                   |                          | rkspace.                          |
# | type                                              | text                     | The type of the Log Analytics wor |
# |                                                   |                          | kspace.                           |
# | workspace_capping                                 | jsonb                    | The workspace capping properties. |
# +---------------------------------------------------+--------------------------+-----------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    location,
    name,
    type,
    sku,
    retention_in_days,
    tags
from 
    azure_log_analytics_workspace
" --output csv 1>azure_log_analytics_workspace.csv 2>&1
