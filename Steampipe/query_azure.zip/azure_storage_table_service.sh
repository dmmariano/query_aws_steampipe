# .inspect azure_storage_table_service;
# +----------------------+-------+-------------------------------------------------------------------------------+
# | column               | type  | description                                                                   |
# +----------------------+-------+-------------------------------------------------------------------------------+
# | _ctx                 | jsonb | Steampipe context in JSON form.                                               |
# | akas                 | jsonb | Array of globally unique identifier strings (also known as) for the resource. |
# | cloud_environment    | text  | The Azure Cloud Environment.                                                  |
# | cors_rules           | jsonb | A list of CORS rules                                                          |
# | id                   | text  | Contains ID to identify a table service uniquely                              |
# | name                 | text  | The friendly name that identifies the table service                           |
# | region               | text  | The Azure region/location in which the resource is located.                   |
# | resource_group       | text  | The resource group which holds this resource.                                 |
# | sp_connection_name   | text  | Steampipe connection name.                                                    |
# | sp_ctx               | jsonb | Steampipe context in JSON form.                                               |
# | storage_account_name | text  | An unique read-only string that changes whenever the resource is updated      |
# | subscription_id      | text  | The Azure Subscription ID in which the resource is located.                   |
# | title                | text  | Title of the resource.                                                        |
# | type                 | text  | Type of the resource                                                          |
# +----------------------+-------+-------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    storage_account_name,
    type
from
    ${TABLE_PREFIX}azure_storage_table_service;
" --output csv 1>azure_storage_table_service.csv 2>&1