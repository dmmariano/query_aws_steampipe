# .inspect azure_sql_server
# +---------------------------------+-------+-------------------------------------------------------------------------------+
# | column                          | type  | description                                                                   |
# +---------------------------------+-------+-------------------------------------------------------------------------------+
# | _ctx                            | jsonb | Steampipe context in JSON form.                                               |
# | administrator_login             | text  | Specifies the username of the administrator for this server.                  |
# | administrator_login_password    | text  | The administrator login password.                                             |
# | akas                            | jsonb | Array of globally unique identifier strings (also known as) for the resource. |
# | cloud_environment               | text  | The Azure Cloud Environment.                                                  |
# | encryption_protector            | jsonb | The server encryption protector.                                              |
# | firewall_rules                  | jsonb | A list of firewall rules fro this server.                                     |
# | fully_qualified_domain_name     | text  | The fully qualified domain name of the server.                                |
# | id                              | text  | Contains ID to identify a SQL server uniquely.                                |
# | kind                            | text  | The Kind of sql server.                                                       |
# | location                        | text  | The resource location.                                                        |
# | minimal_tls_version             | text  | Minimal TLS version. Allowed values: '1.0', '1.1', '1.2'.                     |
# | name                            | text  | The friendly name that identifies the SQL server.                             |
# | private_endpoint_connections    | jsonb | The private endpoint connections of the sql server.                           |
# | public_network_access           | text  | Whether or not public endpoint access is allowed for this server.             |
# | region                          | text  | The Azure region/location in which the resource is located.                   |
# | resource_group                  | text  | The resource group which holds this resource.                                 |
# | server_audit_policy             | jsonb | Specifies the audit policy configuration for server.                          |
# | server_azure_ad_administrator   | jsonb | Specifies the active directory administrator.                                 |
# | server_security_alert_policy    | jsonb | Specifies the security alert policy configuration for server.                 |
# | server_vulnerability_assessment | jsonb | Specifies the server's vulnerability assessment.                              |
# | sp_connection_name              | text  | Steampipe connection name.                                                    |
# | sp_ctx                          | jsonb | Steampipe context in JSON form.                                               |
# | state                           | text  | The state of the server.                                                      |
# | subscription_id                 | text  | The Azure Subscription ID in which the resource is located.                   |
# | tags                            | jsonb | A map of tags for the resource.                                               |
# | tags_src                        | jsonb | Specifies the set of tags attached to the server.                             |
# | title                           | text  | Title of the resource.                                                        |
# | type                            | text  | The resource type of the SQL server.                                          |
# | version                         | text  | The version of the server.                                                    |
# | virtual_network_rules           | jsonb | A list of virtual network rules for this server.                              |
# +---------------------------------+-------+-------------------------------------------------------------------------------+

time steampipe query "
select
  subscription_id,
  resource_group,
  region as location,
  state as status,
  name,
  type,
  kind as version,
  tags
from
  ${TABLE_PREFIX}azure_sql_server;
" --output csv >azure_sql_server.csv 2>&1