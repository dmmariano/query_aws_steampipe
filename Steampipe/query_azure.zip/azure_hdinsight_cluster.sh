# .inspect azure_hdinsight_cluster
# +----------------------------------+-------+---------------------------------------------------------------------+
# | column                           | type  | description                                                         |
# +----------------------------------+-------+---------------------------------------------------------------------+
# | _ctx                             | jsonb | Steampipe context in JSON form.                                     |
# | akas                             | jsonb | Array of globally unique identifier strings (also known as) for the |
# |                                  |       |  resource.                                                          |
# | cloud_environment                | text  | The Azure Cloud Environment.                                        |
# | cluster_definition               | jsonb | The cluster definition.                                             |
# | cluster_hdp_version              | text  | The hdp version of the cluster.                                     |
# | cluster_id                       | text  | The cluster id.                                                     |
# | cluster_state                    | text  | The state of the cluster.                                           |
# | cluster_version                  | text  | The version of the cluster.                                         |
# | compute_isolation_properties     | jsonb | The compute isolation properties of the cluster.                    |
# | compute_profile                  | jsonb | The complete profile of the cluster.                                |
# | connectivity_endpoints           | jsonb | The list of connectivity endpoints.                                 |
# | created_date                     | text  | The date on which the cluster was created.                          |
# | diagnostic_settings              | jsonb | A list of active diagnostic settings for the cluster.               |
# | disk_encryption_properties       | jsonb | The disk encryption properties of the cluster.                      |
# | encryption_in_transit_properties | jsonb | The encryption-in-transit properties of the cluster.                |
# | errors                           | jsonb | The list of errors.                                                 |
# | etag                             | text  | The ETag for the resource.                                          |
# | excluded_services_config         | jsonb | The excluded services config of the cluster.                        |
# | id                               | text  | Fully qualified resource Id for the resource.                       |
# | identity                         | jsonb | The identity of the cluster, if configured.                         |
# | kafka_rest_properties            | jsonb | The cluster kafka rest proxy configuration.                         |
# | min_supported_tls_version        | text  | The minimal supported tls version of the cluster.                   |
# | name                             | text  | The name of the resource.                                           |
# | network_properties               | jsonb | The network properties of the cluster.                              |
# | os_type                          | text  | The type of operating system. Possible values include: 'Windows', ' |
# |                                  |       | Linux'.                                                             |
# | provisioning_state               | text  | The provisioning state, which only appears in the response. Possibl |
# |                                  |       | e values include: 'InProgress', 'Failed', 'Succeeded', 'Canceled',  |
# |                                  |       | 'Deleting'.                                                         |
# | quota_info                       | jsonb | The quota information of the cluster.                               |
# | region                           | text  | The Azure region/location in which the resource is located.         |
# | resource_group                   | text  | The resource group which holds this resource.                       |
# | security_profile                 | jsonb | The security profile of the cluster.                                |
# | sp_connection_name               | text  | Steampipe connection name.                                          |
# | sp_ctx                           | jsonb | Steampipe context in JSON form.                                     |
# | storage_profile                  | jsonb | The storage profile of the cluster.                                 |
# | subscription_id                  | text  | The Azure Subscription ID in which the resource is located.         |
# | tags                             | jsonb | A map of tags for the resource.                                     |
# | tier                             | text  | The cluster tier. Possible values include: 'Standard', 'Premium'.   |
# | title                            | text  | Title of the resource.                                              |
# | type                             | text  | The type of the resource.                                           |
# +----------------------------------+-------+---------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    cluster_state,
    type,
    os_type,
    cluster_hdp_version,
    cluster_version,
    tier,
    quota_info,
    cluster_definition,
    compute_profile,
    tags
from 
    ${TABLE_PREFIX}azure_hdinsight_cluster
" --output csv 1>azure_hdinsight_cluster.csv 2>&1
