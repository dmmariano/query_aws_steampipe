# .inspect azure_mssql_virtual_machine
# +-------------------------------------------+-------+-------------------------------------------------------------------+
# | column                                    | type  | description                                                       |
# +-------------------------------------------+-------+-------------------------------------------------------------------+
# | _ctx                                      | jsonb | Steampipe context in JSON form.                                   |
# | akas                                      | jsonb | Array of globally unique identifier strings (also known as) for t |
# |                                           |       | he resource.                                                      |
# | auto_backup_settings                      | jsonb | Auto backup settings for SQL Server.                              |
# | auto_patching_settings                    | jsonb | Auto patching settings for applying critical security updates to  |
# |                                           |       | SQL virtual machine.                                              |
# | cloud_environment                         | text  | The Azure Cloud Environment.                                      |
# | id                                        | text  | The resource ID.                                                  |
# | identity                                  | jsonb | Azure Active Directory identity for the SQL virtual machine.      |
# | key_vault_credential_settings             | jsonb | Key vault credential settings for the SQL virtual machine.        |
# | name                                      | text  | The resource name.                                                |
# | provisioning_state                        | text  | Provisioning state to track the async operation status.           |
# | region                                    | text  | The Azure region/location in which the resource is located.       |
# | resource_group                            | text  | The resource group which holds this resource.                     |
# | server_configurations_management_settings | jsonb | SQL server configuration management settings for the SQL virtual  |
# |                                           |       | machine.                                                          |
# | sp_connection_name                        | text  | Steampipe connection name.                                        |
# | sp_ctx                                    | jsonb | Steampipe context in JSON form.                                   |
# | sql_image_offer                           | text  | SQL image offer for the SQL virtual machine.                      |
# | sql_image_sku                             | text  | SQL Server edition type. Possible values include: 'Developer', 'E |
# |                                           |       | xpress', 'Standard', 'Enterprise', 'Web'.                         |
# | sql_management                            | text  | SQL Server Management type. Possible values include: 'Full', 'Lig |
# |                                           |       | htWeight', 'NoAgent'.                                             |
# | sql_server_license_type                   | text  | SQL server license type for the SQL virtual machine. Possible val |
# |                                           |       | ues include: 'PAYG', 'AHUB', 'DR'.                                |
# | sql_virtual_machine_group_resource_id     | text  | ARM resource id of the SQL virtual machine group this SQL virtual |
# |                                           |       |  machine is or will be part of.                                   |
# | storage_configuration_settings            | jsonb | Storage configuration settings for the SQL virtual machine.       |
# | subscription_id                           | text  | The Azure Subscription ID in which the resource is located.       |
# | tags                                      | jsonb | A map of tags for the resource.                                   |
# | title                                     | text  | Title of the resource.                                            |
# | type                                      | text  | The resource type.                                                |
# | virtual_machine_resource_id               | text  | ARM resource id of underlying virtual machine created from SQL ma |
# |                                           |       | rketplace image.                                                  |
# | wsfc_domain_credentials                   | jsonb | Domain credentials for setting up Windows Server Failover Cluster |
# |                                           |       |  for SQL availability group.                                      |
# +-------------------------------------------+-------+-------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    sql_image_offer,
    sql_image_sku,
    sql_management,
    sql_server_license_type,
    virtual_machine_resource_id,
    tags
from
    ${TABLE_PREFIX}azure_mssql_virtual_machine;
" --output csv >azure_mssql_virtual_machine.csv 2>&1