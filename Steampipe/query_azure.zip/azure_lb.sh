# .inspect azure_lb;
# +----------------------------+-------+---------------------------------------------------------------------------------+
# | column                     | type  | description                                                                     |
# +----------------------------+-------+---------------------------------------------------------------------------------+
# | _ctx                       | jsonb | Steampipe context in JSON form.                                                 |
# | akas                       | jsonb | Array of globally unique identifier strings (also known as) for the resource.   |
# | backend_address_pools      | jsonb | Collection of backend address pools used by the load balancer.                  |
# | cloud_environment          | text  | The Azure Cloud Environment.                                                    |
# | diagnostic_settings        | jsonb | A list of active diagnostic settings for the load balancer.                     |
# | etag                       | text  | A unique read-only string that changes whenever the resource is updated.        |
# | extended_location_name     | text  | The name of the extended location.                                              |
# | extended_location_type     | text  | The type of the extended location. Possible values include: 'ExtendedLocationTy |
# |                            |       | pesEdgeZone'.                                                                   |
# | frontend_ip_configurations | jsonb | Object representing the frontend IPs to be used for the load balancer.          |
# | id                         | text  | The resource ID.                                                                |
# | inbound_nat_pools          | jsonb | Defines an external port range for inbound NAT to a single backend port on NICs |
# |                            |       |  associated with the load balancer. Inbound NAT rules are created automatically |
# |                            |       |  for each NIC associated with the Load Balancer using an external port from thi |
# |                            |       | s range. Defining an Inbound NAT pool on the Load Balancer is mutually exclusiv |
# |                            |       | e with defining inbound Nat rules. Inbound NAT pools are referenced from virtua |
# |                            |       | l machine scale sets. NICs that are associated with individual virtual machines |
# |                            |       |  cannot reference an inbound NAT pool. They have to reference individual inboun |
# |                            |       | d NAT rules.                                                                    |
# | inbound_nat_rules          | jsonb | Collection of inbound NAT Rules used by the load balancer. Defining inbound NAT |
# |                            |       |  rules on the load balancer is mutually exclusive with defining an inbound NAT  |
# |                            |       | pool. Inbound NAT pools are referenced from virtual machine scale sets. NICs th |
# |                            |       | at are associated with individual virtual machines cannot reference an Inbound  |
# |                            |       | NAT pool. They have to reference individual inbound NAT rules.                  |
# | load_balancing_rules       | jsonb | Object collection representing the load balancing rules Gets the provisioning.  |
# | name                       | text  | The resource name.                                                              |
# | outbound_rules             | jsonb | The outbound rules.                                                             |
# | probes                     | jsonb | Collection of probe objects used in the load balancer.                          |
# | provisioning_state         | text  | The provisioning state of the load balancer resource. Possible values include:  |
# |                            |       | 'Succeeded', 'Updating', 'Deleting', 'Failed'.                                  |
# | region                     | text  | The Azure region/location in which the resource is located.                     |
# | resource_group             | text  | The resource group which holds this resource.                                   |
# | resource_guid              | text  | The resource GUID property of the load balancer resource.                       |
# | sku_name                   | text  | Name of the load balancer SKU. Possible values include: 'Basic', 'Standard', 'G |
# |                            |       | ateway'.                                                                        |
# | sku_tier                   | text  | Tier of the load balancer SKU. Possible values include: 'Regional', 'Global'.   |
# | sp_connection_name         | text  | Steampipe connection name.                                                      |
# | sp_ctx                     | jsonb | Steampipe context in JSON form.                                                 |
# | subscription_id            | text  | The Azure Subscription ID in which the resource is located.                     |
# | tags                       | jsonb | A map of tags for the resource.                                                 |
# | title                      | text  | Title of the resource.                                                          |
# | type                       | text  | The resource type.                                                              |
# +----------------------------+-------+---------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    sku_name,
    sku_tier,
    tags
from 
    ${TABLE_PREFIX}azure_lb
" --output csv 1>azure_lb.csv 2>&1
