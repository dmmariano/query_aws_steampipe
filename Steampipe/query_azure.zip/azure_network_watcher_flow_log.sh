# .inspect azure_network_watcher_flow_log;
# +--------------------------+---------+-------------------------------------------------------------------------------+
# | column                   | type    | description                                                                   |
# +--------------------------+---------+-------------------------------------------------------------------------------+
# | _ctx                     | jsonb   | Steampipe context in JSON form.                                               |
# | akas                     | jsonb   | Array of globally unique identifier strings (also known as) for the resource. |
# | cloud_environment        | text    | The Azure Cloud Environment.                                                  |
# | enabled                  | boolean | Indicates whether the flow log is enabled, or not.                            |
# | etag                     | text    | An unique read-only string that changes whenever the resource is updated.     |
# | file_type                | text    | The file type of flow log. Possible values include: 'JSON'.                   |
# | id                       | text    | Contains ID to identify a flow log uniquely.                                  |
# | name                     | text    | The friendly name that identifies the flow log.                               |
# | network_watcher_name     | text    | The friendly name that identifies the network watcher.                        |
# | provisioning_state       | text    | The provisioning state of the flow log.                                       |
# | region                   | text    | The Azure region/location in which the resource is located.                   |
# | resource_group           | text    | The resource group which holds this resource.                                 |
# | retention_policy_days    | bigint  | Specifies the number of days to retain flow log records.                      |
# | retention_policy_enabled | boolean | Indicates whether flow log retention is enabled, or not.                      |
# | sp_connection_name       | text    | Steampipe connection name.                                                    |
# | sp_ctx                   | jsonb   | Steampipe context in JSON form.                                               |
# | storage_id               | text    | The ID of the storage account which is used to store the flow log.            |
# | subscription_id          | text    | The Azure Subscription ID in which the resource is located.                   |
# | tags                     | jsonb   | A map of tags for the resource.                                               |
# | target_resource_guid     | text    | The Guid of network security group to which flow log will be applied.         |
# | target_resource_id       | text    | The ID of network security group to which flow log will be applied.           |
# | title                    | text    | Title of the resource.                                                        |
# | traffic_analytics        | jsonb   | Defines the configuration of flow log traffic analytics.                      |
# | type                     | text    | The resource type of the flow log.                                            |
# | version                  | bigint  | The version (revision) of the flow log.                                       |
# +--------------------------+---------+-------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    network_watcher_name,
    type,
    retention_policy_days,
    tags
from 
    ${TABLE_PREFIX}azure_network_watcher_flow_log;
" --output csv 1>azure_network_watcher_flow_log.csv 2>&1
