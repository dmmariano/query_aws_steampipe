# .inspect azure_sql_database
# +----------------------------------------------+--------------------------+------------------------------------------------------------------------------------------------+
# | column                                       | type                     | description                                                                                    |
# +----------------------------------------------+--------------------------+------------------------------------------------------------------------------------------------+
# | _ctx                                         | jsonb                    | Steampipe context in JSON form.                                                                |
# | akas                                         | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                  |
# | audit_policy                                 | jsonb                    | The database blob auditing policy.                                                             |
# | cloud_environment                            | text                     | The Azure Cloud Environment.                                                                   |
# | collation                                    | text                     | The collation of the database.                                                                 |
# | containment_state                            | bigint                   | The containment state of the database.                                                         |
# | create_mode                                  | text                     | Specifies the mode of database creation.                                                       |
# | creation_date                                | timestamp with time zone | The creation date of the database.                                                             |
# | current_service_objective_id                 | text                     | The current service level objective ID of the database.                                        |
# | database_id                                  | text                     | The ID of the database.                                                                        |
# | default_secondary_location                   | text                     | The default secondary region for this database.                                                |
# | earliest_restore_date                        | timestamp with time zone | This records the earliest start date and time that restore is available for this database.     |
# | edition                                      | text                     | The edition of the database.                                                                   |
# | elastic_pool_name                            | text                     | The name of the elastic pool the database is in.                                               |
# | failover_group_id                            | text                     | The resource identifier of the failover group containing this database.                        |
# | id                                           | text                     | Contains ID to identify a database uniquely.                                                   |
# | kind                                         | text                     | Kind of the database.                                                                          |
# | location                                     | text                     | Location of the database.                                                                      |
# | max_size_bytes                               | text                     | The max size of the database expressed in bytes.                                               |
# | name                                         | text                     | The friendly name that identifies the database.                                                |
# | read_scale                                   | text                     | ReadScale indicates whether read-only connections are allowed to this database or not if the d |
# |                                              |                          | atabase is a geo-secondary.                                                                    |
# | recommended_index                            | jsonb                    | The recommended indices for this database.                                                     |
# | recovery_services_recovery_point_resource_id | text                     | Specifies the resource ID of the recovery point to restore from if createMode is RestoreLongTe |
# |                                              |                          | rmRetentionBackup.                                                                             |
# | region                                       | text                     | The Azure region/location in which the resource is located.                                    |
# | requested_service_objective_id               | text                     | The configured service level objective ID of the database.                                     |
# | requested_service_objective_name             | text                     | The name of the configured service level objective of the database.                            |
# | resource_group                               | text                     | The resource group which holds this resource.                                                  |
# | restore_point_in_time                        | timestamp with time zone | Specifies the point in time of the source database that will be restored to create the new dat |
# |                                              |                          | abase.                                                                                         |
# | retention_policy_id                          | text                     | Retention policy ID.                                                                           |
# | retention_policy_name                        | text                     | Retention policy Name.                                                                         |
# | retention_policy_property                    | jsonb                    | Long term Retention policy Property.                                                           |
# | retention_policy_type                        | text                     | Long term Retention policy Type.                                                               |
# | sample_name                                  | jsonb                    | Indicates the name of the sample schema to apply when creating this database.                  |
# | server_name                                  | text                     | The name of the parent server of the database.                                                 |
# | service_level_objective                      | jsonb                    | The current service level objective of the database.                                           |
# | service_tier_advisors                        | jsonb                    | The list of service tier advisors for this database.                                           |
# | source_database_deletion_date                | timestamp with time zone | Specifies the time that the database was deleted when createMode is Restore and sourceDatabase |
# |                                              |                          | Id is the deleted database's original resource id.                                             |
# | source_database_id                           | text                     | Specifies the resource ID of the source database if createMode is Copy, NonReadableSecondary,  |
# |                                              |                          | OnlineSecondary, PointInTimeRestore, Recovery, or Restore.                                     |
# | sp_connection_name                           | text                     | Steampipe connection name.                                                                     |
# | sp_ctx                                       | jsonb                    | Steampipe context in JSON form.                                                                |
# | status                                       | text                     | The status of the database.                                                                    |
# | subscription_id                              | text                     | The Azure Subscription ID in which the resource is located.                                    |
# | tags                                         | jsonb                    | A map of tags for the resource.                                                                |
# | title                                        | text                     | Title of the resource.                                                                         |
# | transparent_data_encryption                  | jsonb                    | The transparent data encryption info for this database.                                        |
# | type                                         | text                     | Type of the database.                                                                          |
# | vulnerability_assessment_scan_records        | jsonb                    | The vulnerability assessment scan records for this database.                                   |
# | vulnerability_assessments                    | jsonb                    | The vulnerability assessments for this database.                                               |
# | zone_redundant                               | boolean                  | Indicates if the database is zone redundant or not.                                            |
# +----------------------------------------------+--------------------------+------------------------------------------------------------------------------------------------+

# Show database editions available for the currently active subscription.

# Includes available service objectives and storage limits. In order to reduce verbosity,
# settings to intentionally reduce storage limits are hidden by default.

# https://learn.microsoft.com/en-us/cli/azure/sql/db?view=azure-cli-latest#code-try-30

# Comando para retornar o descritivo

# LOCATION="brazilsouth"
# SERVICE_OBJECTIVE="GP_S_Gen5_2"

# az sql db list-editions \
# --location ${LOCATION} \
# --service-objective ${SERVICE_OBJECTIVE} \ 
# --show-details max-size

time steampipe query "
select
  subscription_id,
  resource_group,
  location,
  default_secondary_location as location_secondary,
  status,
  name,
  server_name,
  type,
  kind,
  requested_service_objective_name,
  \"collation\",
  max_size_bytes,
  retention_policy_type,
  zone_redundant,
  read_scale,
  tags
from
  ${TABLE_PREFIX}azure_sql_database;
" --output csv 1>azure_sql_database.csv 2>&1
