# .inspect azure_batch_account
# +---------------------------------------------+---------+----------------------------------------------------------+
# | column                                      | type    | description                                              |
# +---------------------------------------------+---------+----------------------------------------------------------+
# | _ctx                                        | jsonb   | Steampipe context in JSON form.                          |
# | account_endpoint                            | text    | The account endpoint used to interact with the batch ser |
# |                                             |         | vice.                                                    |
# | active_job_and_job_schedule_quota           | text    | Active job and job schedule quota of the batch account.  |
# | akas                                        | jsonb   | Array of globally unique identifier strings (also known  |
# |                                             |         | as) for the resource.                                    |
# | auto_storage                                | jsonb   | The auto storage properties of the batch account.        |
# | cloud_environment                           | text    | The Azure Cloud Environment.                             |
# | dedicated_core_quota                        | bigint  | The dedicated core quota of the batch account.           |
# | dedicated_core_quota_per_vm_family          | jsonb   | A list of the dedicated core quota per virtual machine f |
# |                                             |         | amily for the batch account.                             |
# | dedicated_core_quota_per_vm_family_enforced | boolean | Batch is transitioning its core quota system for dedicat |
# |                                             |         | ed cores to be enforced per Virtual Machine family. Duri |
# |                                             |         | ng this transitional phase, the dedicated core quota per |
# |                                             |         |  Virtual Machine family may not yet be enforced.         |
# | diagnostic_settings                         | jsonb   | A list of active diagnostic settings for the batch accou |
# |                                             |         | nt.                                                      |
# | encryption                                  | jsonb   | Properties to enable customer managed key for the batch  |
# |                                             |         | account.                                                 |
# | id                                          | text    | The resource identifier.                                 |
# | identity                                    | jsonb   | The identity of the batch account.                       |
# | key_vault_reference                         | jsonb   | Key vault reference of the batch account.                |
# | low_priority_core_quota                     | bigint  | The low priority core quota of the batch account.        |
# | name                                        | text    | The resource name.                                       |
# | pool_allocation_mode                        | text    | The pool allocation mode of the batch account.           |
# | pool_quota                                  | bigint  | The pool quota of the batch account.                     |
# | private_endpoint_connections                | jsonb   | The properties associated with the private endpoint conn |
# |                                             |         | ection.                                                  |
# | provisioning_state                          | text    | The provisioned state of the batch account.              |
# | public_network_access                       | text    | Indicates whether or not public network access is allowe |
# |                                             |         | d for the batch account.                                 |
# | region                                      | text    | The Azure region/location in which the resource is locat |
# |                                             |         | ed.                                                      |
# | resource_group                              | text    | The resource group which holds this resource.            |
# | sp_connection_name                          | text    | Steampipe connection name.                               |
# | sp_ctx                                      | jsonb   | Steampipe context in JSON form.                          |
# | subscription_id                             | text    | The Azure Subscription ID in which the resource is locat |
# |                                             |         | ed.                                                      |
# | tags                                        | jsonb   | A map of tags for the resource.                          |
# | title                                       | text    | Title of the resource.                                   |
# | type                                        | text    | The resource type.                                       |
# +---------------------------------------------+---------+----------------------------------------------------------+

time steampipe query "
select
    subscription_id
    resource_group,
    region as location,
    name
    type,  
    pool_allocation_mode, 
    pool_quota,  
    public_network_access,
    tags
from
    ${TABLE_PREFIX}azure_batch_account;
" --output csv 1>azure_batch_account.csv 2>&1