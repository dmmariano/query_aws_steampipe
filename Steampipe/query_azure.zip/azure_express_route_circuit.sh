# .inspect azure_express_route_circuit
# +-------------------------------------+------------------+-------------------------------------------------------+
# | column                              | type             | description                                           |
# +-------------------------------------+------------------+-------------------------------------------------------+
# | _ctx                                | jsonb            | Steampipe context in JSON form.                       |
# | akas                                | jsonb            | Array of globally unique identifier strings (also kno |
# |                                     |                  | wn as) for the resource.                              |
# | allow_classic_operations            | boolean          | Allow classic operations.                             |
# | authorizations                      | jsonb            | The list of authorizations.                           |
# | bandwidth_in_gbps                   | double precision | The bandwidth of the circuit when the circuit is prov |
# |                                     |                  | isioned on an ExpressRoutePort resource.              |
# | circuit_provisioning_state          | text             | The CircuitProvisioningState state of the resource.   |
# | cloud_environment                   | text             | The Azure Cloud Environment.                          |
# | etag                                | text             | An unique read-only string that changes whenever the  |
# |                                     |                  | resource is updated.                                  |
# | express_route_port                  | jsonb            | The reference to the ExpressRoutePort resource when t |
# |                                     |                  | he circuit is provisioned on an ExpressRoutePort reso |
# |                                     |                  | urce.                                                 |
# | global_reach_enabled                | boolean          | Flag denoting global reach status.                    |
# | id                                  | text             | Resource ID.                                          |
# | name                                | text             | The friendly name that identifies the circuit.        |
# | peerings                            | jsonb            | The list of peerings.                                 |
# | provisioning_state                  | text             | The provisioning state of the express route circuit r |
# |                                     |                  | esource. Possible values include: 'Succeeded', 'Updat |
# |                                     |                  | ing', 'Deleting', 'Failed'.                           |
# | region                              | text             | The Azure region/location in which the resource is lo |
# |                                     |                  | cated.                                                |
# | resource_group                      | text             | The resource group which holds this resource.         |
# | service_key                         | text             | The ServiceKey.                                       |
# | service_provider_notes              | text             | The ServiceProviderNotes.                             |
# | service_provider_properties         | jsonb            | The ServiceProviderProperties.                        |
# | service_provider_provisioning_state | text             | The ServiceProviderProvisioningState state of the res |
# |                                     |                  | ource. Possible values include: 'NotProvisioned', 'Pr |
# |                                     |                  | ovisioning', 'Provisioned', 'Deprovisioning'.         |
# | sku_family                          | text             | The family of the SKU. Possible values include: 'Unli |
# |                                     |                  | mitedData', 'MeteredData'.                            |
# | sku_name                            | text             | The name of the SKU.                                  |
# | sku_tier                            | text             | The tier of the SKU. Possible values include: 'Standa |
# |                                     |                  | rd', 'Premium', 'Basic', 'Local'.                     |
# | sp_connection_name                  | text             | Steampipe connection name.                            |
# | sp_ctx                              | jsonb            | Steampipe context in JSON form.                       |
# | subscription_id                     | text             | The Azure Subscription ID in which the resource is lo |
# |                                     |                  | cated.                                                |
# | tags                                | jsonb            | A map of tags for the resource.                       |
# | title                               | text             | Title of the resource.                                |
# +-------------------------------------+------------------+-------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    sku_name,
    sku_tier,
    sku_family,
    circuit_provisioning_state,
    service_provider_properties,
    bandwidth_in_gbps,
    tags
from 
    ${TABLE_PREFIX}azure_express_route_circuit
" --output csv 1>azure_express_route_circuit.csv 2>&1
