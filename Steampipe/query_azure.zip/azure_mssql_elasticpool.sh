# .inspect   azure_mssql_elasticpool;
# +--------------------+--------------------------+------------------------------------------------------------------+
# | column             | type                     | description                                                      |
# +--------------------+--------------------------+------------------------------------------------------------------+
# | _ctx               | jsonb                    | Steampipe context in JSON form.                                  |
# | akas               | jsonb                    | Array of globally unique identifier strings (also known as) for  |
# |                    |                          | the resource.                                                    |
# | cloud_environment  | text                     | The Azure Cloud Environment.                                     |
# | creation_date      | timestamp with time zone | The creation date of the elastic pool.                           |
# | database_dtu_max   | bigint                   | The maximum DTU any one database can consume.                    |
# | database_dtu_min   | bigint                   | The minimum DTU all databases are guaranteed.                    |
# | dtu                | bigint                   | The total shared DTU for the database elastic pool.              |
# | edition            | text                     | The edition of the elastic pool.                                 |
# | id                 | text                     | Contains ID to identify a elastic pool uniquely.                 |
# | kind               | text                     | The kind of elastic pool.                                        |
# | name               | text                     | The friendly name that identifies the elastic pool.              |
# | region             | text                     | The Azure region/location in which the resource is located.      |
# | resource_group     | text                     | The resource group which holds this resource.                    |
# | server_name        | text                     | The name of the parent server of the elastic pool.               |
# | sp_connection_name | text                     | Steampipe connection name.                                       |
# | sp_ctx             | jsonb                    | Steampipe context in JSON form.                                  |
# | state              | text                     | The state of the elastic pool.                                   |
# | storage_mb         | bigint                   | Storage limit for the database elastic pool in MB.               |
# | subscription_id    | text                     | The Azure Subscription ID in which the resource is located.      |
# | tags               | jsonb                    | A map of tags for the resource.                                  |
# | title              | text                     | Title of the resource.                                           |
# | type               | text                     | The resource type of the elastic pool.                           |
# | zone_redundant     | boolean                  | Whether or not this database elastic pool is zone redundant, whi |
# |                    |                          | ch means the replicas of this database will be spread across mul |
# |                    |                          | tiple availability zones.                                        |
# +--------------------+--------------------------+------------------------------------------------------------------+

time steampipe query "
select
    subscription_id
    resource_group,
    region as location,
    state as status,
    name,
    server_name,
    type,
    kind,
    storage_mb,
    dtu as shared_DTU,
    zone_redundant,
    tags
from
  ${TABLE_PREFIX}azure_mssql_elasticpool;
" --output csv 1>azure_mssql_elasticpool.csv 2>&1