# .inspect azure_mssql_managed_instance
# +------------------------------+--------------------------+-------------------------------------------------------------+
# | column                       | type                     | description                                                 |
# +------------------------------+--------------------------+-------------------------------------------------------------+
# | _ctx                         | jsonb                    | Steampipe context in JSON form.                             |
# | administrator_login          | text                     | Administrator username for the managed instance.            |
# | administrator_login_password | text                     | Administrator password for the managed instance.            |
# | akas                         | jsonb                    | Array of globally unique identifier strings (also known as) |
# |                              |                          |  for the resource.                                          |
# | cloud_environment            | text                     | The Azure Cloud Environment.                                |
# | collation                    | text                     | Collation of the managed instance.                          |
# | dns_zone                     | text                     | The Dns zone that the managed instance is in.               |
# | dns_zone_partner             | text                     | The resource id of another managed instance whose DNS zone  |
# |                              |                          | this managed instance will share after creation.            |
# | encryption_protectors        | jsonb                    | The managed instance encryption protectors.                 |
# | fully_qualified_domain_name  | text                     | The fully qualified domain name of the managed instance.    |
# | id                           | text                     | Contains ID to identify a managed instance uniquely.        |
# | identity                     | jsonb                    | The azure active directory identity of the managed instance |
# |                              |                          | .                                                           |
# | instance_pool_id             | text                     | The Id of the instance pool this managed server belongs to. |
# | license_type                 | text                     | The license type of the managed instance.                   |
# | maintenance_configuration_id | text                     | Specifies maintenance configuration id to apply to this man |
# |                              |                          | aged instance.                                              |
# | managed_instance_create_mode | text                     | Specifies the mode of database creation.                    |
# | minimal_tls_version          | text                     | Minimal TLS version of the managed instance.                |
# | name                         | text                     | The friendly name that identifies the managed instance.     |
# | proxy_override               | text                     | Connection type used for connecting to the instance.        |
# | public_data_endpoint_enabled | boolean                  | Whether or not the public data endpoint is enabled.         |
# | region                       | text                     | The Azure region/location in which the resource is located. |
# | resource_group               | text                     | The resource group which holds this resource.               |
# | restore_point_in_time        | timestamp with time zone | Specifies the point in time of the source database that wil |
# |                              |                          | l be restored to create the new database.                   |
# | security_alert_policies      | jsonb                    | The security alert policies of the managed instance.        |
# | sku                          | jsonb                    | Managed instance SKU.                                       |
# | source_managed_instance_id   | text                     | The resource identifier of the source managed instance asso |
# |                              |                          | ciated with create operation of this instance.              |
# | sp_connection_name           | text                     | Steampipe connection name.                                  |
# | sp_ctx                       | jsonb                    | Steampipe context in JSON form.                             |
# | state                        | text                     | The state of the managed instance.                          |
# | storage_size_in_gb           | bigint                   | The managed instance storage size in GB.                    |
# | subnet_id                    | text                     | Subnet resource ID for the managed instance.                |
# | subscription_id              | text                     | The Azure Subscription ID in which the resource is located. |
# | tags                         | jsonb                    | A map of tags for the resource.                             |
# | timezone_id                  | text                     | Id of the timezone.                                         |
# | title                        | text                     | Title of the resource.                                      |
# | type                         | text                     | The resource type of the managed instance.                  |
# | v_cores                      | bigint                   | The number of vcores of the managed instance.               |
# | vulnerability_assessments    | jsonb                    | The managed instance vulnerability assessments.             |
# +------------------------------+--------------------------+-------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    state,
    name,
    type,
    license_type,
    storage_size_in_gb,
    v_cores,
    \"collation\",
    tags
from
    ${TABLE_PREFIX}azure_mssql_managed_instance;
" --output csv >azure_mssql_managed_instance.csv 2>&1