# .inspect azure_key_vault
# +---------------------------------+---------+--------------------------------------------------------------------+
# | column                          | type    | description                                                        |
# +---------------------------------+---------+--------------------------------------------------------------------+
# | _ctx                            | jsonb   | Steampipe context in JSON form.                                    |
# | access_policies                 | jsonb   | A list of 0 to 1024 identities that have access to the key vault.  |
# | akas                            | jsonb   | Array of globally unique identifier strings (also known as) for th |
# |                                 |         | e resource.                                                        |
# | cloud_environment               | text    | The Azure Cloud Environment.                                       |
# | create_mode                     | text    | The vault's create mode to indicate whether the vault need to be r |
# |                                 |         | ecovered or not. Possible values include: 'default', 'recover'.    |
# | diagnostic_settings             | jsonb   | A list of active diagnostic settings for the vault.                |
# | enable_rbac_authorization       | boolean | Property that controls how data actions are authorized.            |
# | enabled_for_deployment          | boolean | Indicates whether Azure Virtual Machines are permitted to retrieve |
# |                                 |         |  certificates stored as secrets from the key vault.                |
# | enabled_for_disk_encryption     | boolean | Indicates whether Azure Disk Encryption is permitted to retrieve s |
# |                                 |         | ecrets from the vault and unwrap keys.                             |
# | enabled_for_template_deployment | boolean | Indicates whether Azure Resource Manager is permitted to retrieve  |
# |                                 |         | secrets from the key vault.                                        |
# | id                              | text    | Contains ID to identify a vault uniquely.                          |
# | name                            | text    | The friendly name that identifies the vault.                       |
# | network_acls                    | jsonb   | Rules governing the accessibility of the key vault from specific n |
# |                                 |         | etwork locations.                                                  |
# | private_endpoint_connections    | jsonb   | List of private endpoint connections associated with the key vault |
# |                                 |         | .                                                                  |
# | purge_protection_enabled        | boolean | Indicates whether protection against purge is enabled for this vau |
# |                                 |         | lt.                                                                |
# | region                          | text    | The Azure region/location in which the resource is located.        |
# | resource_group                  | text    | The resource group which holds this resource.                      |
# | sku_family                      | text    | Contains SKU family name.                                          |
# | sku_name                        | text    | SKU name to specify whether the key vault is a standard vault or a |
# |                                 |         |  premium vault.                                                    |
# | soft_delete_enabled             | boolean | Indicates whether the 'soft delete' functionality is enabled for t |
# |                                 |         | his key vault.                                                     |
# | soft_delete_retention_in_days   | bigint  | Contains softDelete data retention days.                           |
# | sp_connection_name              | text    | Steampipe connection name.                                         |
# | sp_ctx                          | jsonb   | Steampipe context in JSON form.                                    |
# | subscription_id                 | text    | The Azure Subscription ID in which the resource is located.        |
# | tags                            | jsonb   | A map of tags for the resource.                                    |
# | tenant_id                       | text    | The Azure Active Directory tenant ID that should be used for authe |
# |                                 |         | nticating requests to the key vault.                               |
# | title                           | text    | Title of the resource.                                             |
# | type                            | text    | Type of the resource.                                              |
# | vault_uri                       | text    | Contains URI of the vault for performing operations on keys and se |
# |                                 |         | crets.                                                             |
# +---------------------------------+---------+--------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    sku_name,
    tags
from 
    ${TABLE_PREFIX}azure_key_vault
" --output csv 1>azure_key_vault.csv 2>&1
