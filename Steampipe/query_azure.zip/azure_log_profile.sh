# .inspect azure_log_profile
# +---------------------+-------+------------------------------------------------------------------------------------+
# | column              | type  | description                                                                        |
# +---------------------+-------+------------------------------------------------------------------------------------+
# | _ctx                | jsonb | Steampipe context in JSON form.                                                    |
# | akas                | jsonb | Array of globally unique identifier strings (also known as) for the resource.      |
# | categories          | jsonb | The categories of the logs.                                                        |
# | cloud_environment   | text  | The Azure Cloud Environment.                                                       |
# | id                  | text  | The resource Id.                                                                   |
# | location            | text  | Specifies the name of the region, the resource is created at.                      |
# | log_event_location  | jsonb | List of regions for which Activity Log events should be stored or streamed.        |
# | name                | text  | The name of the resource.                                                          |
# | region              | text  | The Azure region/location in which the resource is located.                        |
# | resource_group      | text  | The resource group which holds this resource.                                      |
# | retention_policy    | jsonb | The retention policy for the events in the log.                                    |
# | service_bus_rule_id | text  | The service bus rule ID of the service bus namespace in which you would like to ha |
# |                     |       | ve Event Hubs created for streaming the Activity Log.                              |
# | sp_connection_name  | text  | Steampipe connection name.                                                         |
# | sp_ctx              | jsonb | Steampipe context in JSON form.                                                    |
# | storage_account_id  | text  | The resource id of the storage account to which you would like to send the Activit |
# |                     |       | y Log.                                                                             |
# | subscription_id     | text  | The Azure Subscription ID in which the resource is located.                        |
# | tags                | jsonb | A map of tags for the resource.                                                    |
# | title               | text  | Title of the resource.                                                             |
# | type                | text  | Type of the resource.                                                              |
# +---------------------+-------+------------------------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    type,
    log_event_location,
    categories,
    retention_policy,
    tags
from 
    ${TABLE_PREFIX}azure_log_profile;
" --output csv 1>azure_log_profile.csv 2>&1
