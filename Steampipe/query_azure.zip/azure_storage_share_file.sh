# .inspect azure_storage_share_file
# +--------------------------+--------------------------+------------------------------------------------------------+
# | column                   | type                     | description                                                |
# +--------------------------+--------------------------+------------------------------------------------------------+
# | _ctx                     | jsonb                    | Steampipe context in JSON form.                            |
# | access_tier              | text                     | Access tier for specific share. GpV2 account can choose be |
# |                          |                          | tween TransactionOptimized (default), Hot, and Cool.       |
# | access_tier_change_time  | timestamp with time zone | Indicates the last modification time for share access tier |
# |                          |                          | .                                                          |
# | access_tier_status       | text                     | Indicates if there is a pending transition for access tier |
# |                          |                          | .                                                          |
# | akas                     | jsonb                    | Array of globally unique identifier strings (also known as |
# |                          |                          | ) for the resource.                                        |
# | cloud_environment        | text                     | The Azure Cloud Environment.                               |
# | deleted                  | boolean                  | Indicates whether the share was deleted.                   |
# | deleted_time             | timestamp with time zone | The deleted time if the share was deleted.                 |
# | enabled_protocols        | text                     | The authentication protocol that is used for the file shar |
# |                          |                          | e. Can only be specified when creating a share. Possible v |
# |                          |                          | alues include: 'SMB', 'NFS'.                               |
# | id                       | text                     | Fully qualified resource ID for the resource.              |
# | last_modified_time       | timestamp with time zone | Returns the date and time the share was last modified.     |
# | metadata                 | jsonb                    | A name-value pair to associate with the share as metadata. |
# | name                     | text                     | The name of the resource.                                  |
# | remaining_retention_days | bigint                   | Remaining retention days for share that was soft deleted.  |
# | resource_group           | text                     | The resource group which holds this resource.              |
# | root_squash              | text                     | The property is for NFS share only. The default is NoRootS |
# |                          |                          | quash. Possible values include: 'NoRootSquash', 'RootSquas |
# |                          |                          | h', 'AllSquash'.                                           |
# | share_quota              | bigint                   | The maximum size of the share, in gigabytes. Must be great |
# |                          |                          | er than 0, and less than or equal to 5TB (5120). For Large |
# |                          |                          |  File Shares, the maximum size is 102400.                  |
# | share_usage_bytes        | bigint                   | The approximate size of the data stored on the share. Note |
# |                          |                          |  that this value may not include all recently created or r |
# |                          |                          | ecently resized files.                                     |
# | sp_connection_name       | text                     | Steampipe connection name.                                 |
# | sp_ctx                   | jsonb                    | Steampipe context in JSON form.                            |
# | storage_account_name     | text                     | The name of the storage account.                           |
# | subscription_id          | text                     | The Azure Subscription ID in which the resource is located |
# |                          |                          | .                                                          |
# | title                    | text                     | Title of the resource.                                     |
# | type                     | text                     | The type of the resource.                                  |
# | version                  | text                     | The version of the share.                                  |
# +--------------------------+--------------------------+------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    name,
    storage_account_name,
    type,
    enabled_protocols
from
    ${TABLE_PREFIX}azure_storage_share_file;
" --output csv 1>azure_storage_share_file.csv 2>&1