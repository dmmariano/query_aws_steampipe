# .inspect azure_storage_account;
# +--------------------------------------------------------+--------------------------+------------------------------+
# | column                                                 | type                     | description                  |
# +--------------------------------------------------------+--------------------------+------------------------------+
# | _ctx                                                   | jsonb                    | Steampipe context in JSON fo |
# |                                                        |                          | rm.                          |
# | access_keys                                            | jsonb                    | The list of access keys or K |
# |                                                        |                          | erberos keys (if active dire |
# |                                                        |                          | ctory enabled) for the speci |
# |                                                        |                          | fied storage account.        |
# | access_tier                                            | text                     | The access tier used for bil |
# |                                                        |                          | ling.                        |
# | akas                                                   | jsonb                    | Array of globally unique ide |
# |                                                        |                          | ntifier strings (also known  |
# |                                                        |                          | as) for the resource.        |
# | allow_blob_public_access                               | boolean                  | Specifies whether allow or d |
# |                                                        |                          | isallow public access to all |
# |                                                        |                          |  blobs or containers in the  |
# |                                                        |                          | storage account.             |
# | blob_change_feed_enabled                               | boolean                  | Specifies whether change fee |
# |                                                        |                          | d event logging is enabled f |
# |                                                        |                          | or the Blob service.         |
# | blob_container_soft_delete_enabled                     | boolean                  | Specifies whether DeleteRete |
# |                                                        |                          | ntionPolicy is enabled.      |
# | blob_container_soft_delete_retention_days              | bigint                   | Indicates the number of days |
# |                                                        |                          |  that the deleted item shoul |
# |                                                        |                          | d be retained.               |
# | blob_restore_policy_days                               | bigint                   | Specifies how long the blob  |
# |                                                        |                          | can be restored.             |
# | blob_restore_policy_enabled                            | boolean                  | Specifies whether blob resto |
# |                                                        |                          | re is enabled.               |
# | blob_service_logging                                   | jsonb                    | Specifies the blob service p |
# |                                                        |                          | roperties for logging access |
# |                                                        |                          | .                            |
# | blob_soft_delete_enabled                               | boolean                  | Specifies whether DeleteRete |
# |                                                        |                          | ntionPolicy is enabled.      |
# | blob_soft_delete_retention_days                        | bigint                   | Indicates the number of days |
# |                                                        |                          |  that the deleted item shoul |
# |                                                        |                          | d be retained.               |
# | blob_versioning_enabled                                | boolean                  | Specifies whether versioning |
# |                                                        |                          |  is enabled.                 |
# | cloud_environment                                      | text                     | The Azure Cloud Environment. |
# | creation_time                                          | timestamp with time zone | Creation date and time of th |
# |                                                        |                          | e storage account.           |
# | diagnostic_settings                                    | jsonb                    | A list of active diagnostic  |
# |                                                        |                          | settings for the storage acc |
# |                                                        |                          | ount.                        |
# | enable_https_traffic_only                              | boolean                  | Allows https traffic only to |
# |                                                        |                          |  storage service if sets to  |
# |                                                        |                          | true.                        |
# | encryption_key_source                                  | text                     | Contains the encryption keyS |
# |                                                        |                          | ource (provider).            |
# | encryption_key_vault_properties_key_current_version_id | text                     | The object identifier of the |
# |                                                        |                          |  current versioned Key Vault |
# |                                                        |                          |  Key in use.                 |
# | encryption_key_vault_properties_key_name               | text                     | The name of KeyVault key.    |
# | encryption_key_vault_properties_key_vault_uri          | text                     | The Uri of KeyVault.         |
# | encryption_key_vault_properties_key_version            | text                     | The version of KeyVault key. |
# | encryption_key_vault_properties_last_rotation_time     | timestamp with time zone | Timestamp of last rotation o |
# |                                                        |                          | f the Key Vault Key.         |
# | encryption_scope                                       | jsonb                    | Encryption scope details for |
# |                                                        |                          |  the storage account.        |
# | encryption_services                                    | jsonb                    | A list of services which sup |
# |                                                        |                          | port encryption.             |
# | failover_in_progress                                   | boolean                  | Specifies whether the failov |
# |                                                        |                          | er is in progress.           |
# | file_soft_delete_enabled                               | boolean                  | Specifies whether DeleteRete |
# |                                                        |                          | ntionPolicy is enabled.      |
# | file_soft_delete_retention_days                        | bigint                   | Indicates the number of days |
# |                                                        |                          |  that the deleted item shoul |
# |                                                        |                          | d be retained.               |
# | id                                                     | text                     | Contains ID to identify a st |
# |                                                        |                          | orage account uniquely.      |
# | is_hns_enabled                                         | boolean                  | Specifies whether account Hi |
# |                                                        |                          | erarchicalNamespace is enabl |
# |                                                        |                          | ed.                          |
# | kind                                                   | text                     | The kind of the resource.    |
# | lifecycle_management_policy                            | jsonb                    | The managementpolicy associa |
# |                                                        |                          | ted with the specified stora |
# |                                                        |                          | ge account.                  |
# | minimum_tls_version                                    | text                     | Contains the minimum TLS ver |
# |                                                        |                          | sion to be permitted on requ |
# |                                                        |                          | ests to storage.             |
# | name                                                   | text                     | The friendly name that ident |
# |                                                        |                          | ifies the storage account.   |
# | network_ip_rules                                       | jsonb                    | A list of IP ACL rules.      |
# | network_rule_bypass                                    | text                     | Specifies whether traffic is |
# |                                                        |                          |  bypassed for Logging/Metric |
# |                                                        |                          | s/AzureServices.             |
# | network_rule_default_action                            | text                     | Specifies the default action |
# |                                                        |                          |  of allow or deny when no ot |
# |                                                        |                          | her rules match.             |
# | primary_blob_endpoint                                  | text                     | Contains the blob endpoint.  |
# | primary_dfs_endpoint                                   | text                     | Contains the dfs endpoint.   |
# | primary_file_endpoint                                  | text                     | Contains the file endpoint.  |
# | primary_location                                       | text                     | Contains the location of the |
# |                                                        |                          |  primary data center for the |
# |                                                        |                          |  storage account.            |
# | primary_queue_endpoint                                 | text                     | Contains the queue endpoint. |
# | primary_table_endpoint                                 | text                     | Contains the table endpoint. |
# | primary_web_endpoint                                   | text                     | Contains the web endpoint.   |
# | private_endpoint_connections                           | jsonb                    | A list of private endpoint c |
# |                                                        |                          | onnection associated with th |
# |                                                        |                          | e specified storage account. |
# | provisioning_state                                     | text                     | The provisioning state of th |
# |                                                        |                          | e storage account resource.  |
# | public_network_access                                  | text                     | Allow or disallow public net |
# |                                                        |                          | work access to Storage Accou |
# |                                                        |                          | nt. Value is optional but if |
# |                                                        |                          |  passed in, must be Enabled  |
# |                                                        |                          | or Disabled.                 |
# | queue_logging_delete                                   | boolean                  | Specifies whether all delete |
# |                                                        |                          |  requests should be logged.  |
# | queue_logging_read                                     | boolean                  | Specifies whether all read r |
# |                                                        |                          | equests should be logged.    |
# | queue_logging_retention_days                           | bigint                   | Indicates the number of days |
# |                                                        |                          |  that metrics or logging dat |
# |                                                        |                          | a should be retained.        |
# | queue_logging_retention_enabled                        | boolean                  | Specifies whether a retentio |
# |                                                        |                          | n policy is enabled for the  |
# |                                                        |                          | storage service.             |
# | queue_logging_version                                  | text                     | The version of Storage Analy |
# |                                                        |                          | tics to configure.           |
# | queue_logging_write                                    | boolean                  | Specifies whether all write  |
# |                                                        |                          | requests should be logged.   |
# | region                                                 | text                     | The Azure region/location in |
# |                                                        |                          |  which the resource is locat |
# |                                                        |                          | ed.                          |
# | require_infrastructure_encryption                      | boolean                  | Specifies whether or not the |
# |                                                        |                          |  service applies a secondary |
# |                                                        |                          |  layer of encryption with pl |
# |                                                        |                          | atform managed keys for data |
# |                                                        |                          |  at rest.                    |
# | resource_group                                         | text                     | The resource group which hol |
# |                                                        |                          | ds this resource.            |
# | secondary_location                                     | text                     | Contains the location of the |
# |                                                        |                          |  geo-replicated secondary fo |
# |                                                        |                          | r the storage account.       |
# | sku_name                                               | text                     | Contains sku name of the sto |
# |                                                        |                          | rage account.                |
# | sku_tier                                               | text                     | Contains sku tier of the sto |
# |                                                        |                          | rage account.                |
# | sp_connection_name                                     | text                     | Steampipe connection name.   |
# | sp_ctx                                                 | jsonb                    | Steampipe context in JSON fo |
# |                                                        |                          | rm.                          |
# | status_of_primary                                      | text                     | The status indicating whethe |
# |                                                        |                          | r the primary location of th |
# |                                                        |                          | e storage account is availab |
# |                                                        |                          | le or unavailable. Possible  |
# |                                                        |                          | values include: 'available', |
# |                                                        |                          |  'unavailable'.              |
# | status_of_secondary                                    | text                     | The status indicating whethe |
# |                                                        |                          | r the secondary location of  |
# |                                                        |                          | the storage account is avail |
# |                                                        |                          | able or unavailable. Only av |
# |                                                        |                          | ailable if the SKU name is S |
# |                                                        |                          | tandard_GRS or Standard_RAGR |
# |                                                        |                          | S. Possible values include:  |
# |                                                        |                          | 'available', 'unavailable'.  |
# | subscription_id                                        | text                     | The Azure Subscription ID in |
# |                                                        |                          |  which the resource is locat |
# |                                                        |                          | ed.                          |
# | table_logging_delete                                   | boolean                  | Indicates whether all delete |
# |                                                        |                          |  requests should be logged.  |
# | table_logging_read                                     | boolean                  | Indicates whether all read r |
# |                                                        |                          | equests should be logged.    |
# | table_logging_retention_policy                         | jsonb                    | The retention policy.        |
# | table_logging_version                                  | text                     | The version of Analytics to  |
# |                                                        |                          | configure.                   |
# | table_logging_write                                    | boolean                  | Indicates whether all write  |
# |                                                        |                          | requests should be logged.   |
# | table_properties                                       | jsonb                    | Azure Analytics Logging sett |
# |                                                        |                          | ings of tables.              |
# | tags                                                   | jsonb                    | A map of tags for the resour |
# |                                                        |                          | ce.                          |
# | title                                                  | text                     | Title of the resource.       |
# | type                                                   | text                     | Type of the resource.        |
# | virtual_network_rules                                  | jsonb                    | A list of virtual network ru |
# |                                                        |                          | les.                         |
# +--------------------------------------------------------+--------------------------+------------------------------+

time steampipe query "
select
    subscription_id
    resource_group,
    region as location,
    kind,
    name,
    sku_name,
    sku_tier,
    primary_location,
    secondary_location
from
    azure_storage_account;
    -- ${TABLE_PREFIX}azure_storage_account;
" --output csv 1>azure_storage_account.csv 2>&1