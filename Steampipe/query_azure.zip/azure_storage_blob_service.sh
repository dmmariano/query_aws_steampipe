# .inspect azure_storage_blob_service
# +-----------------------------------+---------+--------------------------------------------------------------------+
# | column                            | type    | description                                                        |
# +-----------------------------------+---------+--------------------------------------------------------------------+
# | _ctx                              | jsonb   | Steampipe context in JSON form.                                    |
# | akas                              | jsonb   | Array of globally unique identifier strings (also known as) for th |
# |                                   |         | e resource.                                                        |
# | automatic_snapshot_policy_enabled | boolean | Specifies whether automatic snapshot creation is enabled, or not   |
# | change_feed_enabled               | boolean | Specifies whether change feed event logging is enabled for the Blo |
# |                                   |         | b service                                                          |
# | cloud_environment                 | text    | The Azure Cloud Environment.                                       |
# | container_delete_retention_policy | jsonb   | The blob service properties for container soft delete              |
# | cors_rules                        | jsonb   | A list of CORS rules for a storage account’s Blob service          |
# | default_service_version           | text    | Indicates the default version to use for requests to the Blob serv |
# |                                   |         | ice if an incoming request’s version is not specified              |
# | delete_retention_policy           | jsonb   | The blob service properties for blob soft delete                   |
# | id                                | text    | Contains ID to identify a blob uniquely                            |
# | is_versioning_enabled             | boolean | Specifies whether the versioning is enabled, or not                |
# | name                              | text    | The friendly name that identifies the blob                         |
# | region                            | text    | The Azure region/location in which the resource is located.        |
# | resource_group                    | text    | The resource group which holds this resource.                      |
# | restore_policy                    | jsonb   | The blob service properties for blob restore policy                |
# | sku_name                          | text    | The sku name                                                       |
# | sku_tier                          | text    | Contains the sku tier                                              |
# | sp_connection_name                | text    | Steampipe connection name.                                         |
# | sp_ctx                            | jsonb   | Steampipe context in JSON form.                                    |
# | storage_account_name              | text    | A unique read-only string that changes whenever the resource is up |
# |                                   |         | dated                                                              |
# | subscription_id                   | text    | The Azure Subscription ID in which the resource is located.        |
# | title                             | text    | Title of the resource.                                             |
# | type                              | text    | Type of the resource                                               |
# +-----------------------------------+---------+--------------------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    region as location,
    name,
    storage_account_name,
    type,
    sku_name,
    sku_tier,
    is_versioning_enabled
from
    ${TABLE_PREFIX}azure_storage_blob_service;
" --output csv 1>azure_storage_blob_service.csv 2>&1