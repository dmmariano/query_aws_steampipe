# .inspect azure_storage_container
# +--------------------------------+--------------------------+------------------------------------------------------+
# | column                         | type                     | description                                          |
# +--------------------------------+--------------------------+------------------------------------------------------+
# | _ctx                           | jsonb                    | Steampipe context in JSON form.                      |
# | account_name                   | text                     | The friendly name that identifies the storage accoun |
# |                                |                          | t.                                                   |
# | akas                           | jsonb                    | Array of globally unique identifier strings (also kn |
# |                                |                          | own as) for the resource.                            |
# | cloud_environment              | text                     | The Azure Cloud Environment.                         |
# | default_encryption_scope       | text                     | Default the container to use specified encryption sc |
# |                                |                          | ope for all writes.                                  |
# | deleted                        | boolean                  | Indicates whether the blob container was deleted.    |
# | deleted_time                   | timestamp with time zone | Specifies the time when the container was deleted.   |
# | deny_encryption_scope_override | boolean                  | Indicates whether block override of encryption scope |
# |                                |                          |  from the container default, or not.                 |
# | has_immutability_policy        | boolean                  | The hasImmutabilityPolicy public property is set to  |
# |                                |                          | true by SRP if ImmutabilityPolicy has been created f |
# |                                |                          | or this container. The hasImmutabilityPolicy public  |
# |                                |                          | property is set to false by SRP if ImmutabilityPolic |
# |                                |                          | y has not been created for this container.           |
# | has_legal_hold                 | boolean                  | The hasLegalHold public property is set to true by S |
# |                                |                          | RP if there are at least one existing tag. The hasLe |
# |                                |                          | galHold public property is set to false by SRP if al |
# |                                |                          | l existing legal hold tags are cleared out. There ca |
# |                                |                          | n be a maximum of 1000 blob containers with hasLegal |
# |                                |                          | Hold=true for a given account.                       |
# | id                             | text                     | Contains ID to identify a container uniquely.        |
# | immutability_policy            | jsonb                    | The ImmutabilityPolicy property of the container.    |
# | last_modified_time             | timestamp with time zone | Specifies the date and time the container was last m |
# |                                |                          | odified.                                             |
# | lease_duration                 | text                     | Specifies whether the lease on a container is of inf |
# |                                |                          | inite or fixed duration, only when the container is  |
# |                                |                          | leased. Possible values are: 'Infinite', 'Fixed'.    |
# | lease_state                    | text                     | Specifies the lease state of the container.          |
# | lease_status                   | text                     | Specifies the lease status of the container.         |
# | legal_hold                     | jsonb                    | The LegalHold property of the container.             |
# | metadata                       | jsonb                    | A name-value pair to associate with the container as |
# |                                |                          |  metadata.                                           |
# | name                           | text                     | The friendly name that identifies the container.     |
# | public_access                  | text                     | Specifies whether data in the container may be acces |
# |                                |                          | sed publicly and the level of access.                |
# | remaining_retention_days       | bigint                   | Remaining retention days for soft deleted blob conta |
# |                                |                          | iner.                                                |
# | resource_group                 | text                     | The resource group which holds this resource.        |
# | sp_connection_name             | text                     | Steampipe connection name.                           |
# | sp_ctx                         | jsonb                    | Steampipe context in JSON form.                      |
# | subscription_id                | text                     | The Azure Subscription ID in which the resource is l |
# |                                |                          | ocated.                                              |
# | title                          | text                     | Title of the resource.                               |
# | type                           | text                     | Specifies the type of the container.                 |
# | version                        | text                     | The version of the deleted blob container.           |
# +--------------------------------+--------------------------+------------------------------------------------------+

time steampipe query "
select
    subscription_id,
    resource_group,
    name,
    account_name,
    type,
    public_access,
    default_encryption_scope,
    lease_status,
    lease_state
from
    ${TABLE_PREFIX}azure_storage_container;
" --output csv 1>azure_storage_container.csv 2>&1