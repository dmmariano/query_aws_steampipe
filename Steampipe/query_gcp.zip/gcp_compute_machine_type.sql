/*
+----------------------------------+--------------------------+----------------------------------------------------------------------------------+
| column                           | type                     | description                                                                      |
+----------------------------------+--------------------------+----------------------------------------------------------------------------------+
| _ctx                             | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                            |
| accelerators                     | jsonb                    | A list of accelerator configurations assigned to this machine type.              |
| akas                             | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.    |
| creation_timestamp               | timestamp with time zone | Creation timestamp in RFC3339 text format.                                       |
| description                      | text                     | An optional textual description of the resource.                                 |
| guest_cpus                       | bigint                   | The number of virtual CPUs that are available to the instance.                   |
| id                               | bigint                   | An unique identifier for the resource. This identifier is defined by the server. |
| image_space_gb                   | bigint                   | The amount of memory available for image ig GB.                                  |
| is_shared_cpu                    | boolean                  | Whether this machine type has a shared CPU.                                      |
| kind                             | text                     | The type of the resource. Always compute#machineType for machine types.          |
| maximum_persistent_disks         | bigint                   | Maximum persistent disks allowed.                                                |
| maximum_persistent_disks_size_gb | bigint                   | Maximum total persistent disks size (GB) allowed.                                |
| memory_mb                        | bigint                   | The amount of physical memory available to the instance, defined in MB.          |
| name                             | text                     | Name of the resource.                                                            |
| project                          | text                     | The GCP Project in which the resource is located.                                |
| scratch_disks                    | jsonb                    | A list of extended scratch disks assigned to the instance.                       |
| self_link                        | text                     | Server-defined URL for the resource.                                             |
| title                            | text                     | Title of the resource.                                                           |
+----------------------------------+--------------------------+----------------------------------------------------------------------------------+
*/

export TABLE_PREFIX="jslcloud_production."
time steampipe query "
select
  distinct name,
  description,
  guest_cpus as vcpu,
  memory_mb /1024 as mem_gb,
  is_shared_cpu
from
  ${TABLE_PREFIX}gcp_compute_machine_type
" --output csv 1>.gcp_compute_machine_type.tmp 2>&1

