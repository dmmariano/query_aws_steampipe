/*
+-----------------------------------+--------------------------+-----------------------------------------------------------------------------------------------------+
| column                            | type                     | description                                                                                         |
+-----------------------------------+--------------------------+-----------------------------------------------------------------------------------------------------+
| _ctx                              | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                               |
| addons_config                     | jsonb                    | Configurations for the various addons available to run in the cluster.                              |
| akas                              | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                       |
| authenticator_groups_config       | jsonb                    | Configuration controlling RBAC group membership information.                                        |
| autopilot_enabled                 | boolean                  | Denotes whether autopilot configuration is enabled for the cluster.                                 |
| autoscaling                       | jsonb                    | Cluster-level autoscaling configuration.                                                            |
| binary_authorization              | jsonb                    | Configuration for Binary Authorization.                                                             |
| cluster_ipv4_cidr                 | cidr                     | The IP address range of the container pods in this cluster, in CIDR notation.                       |
| conditions                        | jsonb                    | Which conditions caused the current cluster state.                                                  |
| create_time                       | timestamp with time zone | The time the cluster was created, in RFC3339 text format.                                           |
| current_master_version            | text                     | The current software version of the master endpoint.                                                |
| current_node_count                | bigint                   | The number of nodes currently in the cluster.                                                       |
| current_node_version              | text                     | The current version of the node software components.                                                |
| database_encryption_key_name      | text                     | Name of CloudKMS key to use for the encryption.                                                     |
| database_encryption_state         | text                     | Denotes the state of etcd encryption.                                                               |
| description                       | text                     | An optional description of this cluster.                                                            |
| enable_kubernetes_alpha           | boolean                  | Indicates whether kubernetes alpha features are enabled on this cluster.                            |
| enable_tpu                        | boolean                  | Enable the ability to use Cloud TPUs in this cluster.                                               |
| endpoint                          | text                     | The IP address of this cluster's master endpoint.                                                   |
| expire_time                       | timestamp with time zone | The time the cluster will be automatically deleted.                                                 |
| id                                | text                     | Unique ID of the cluster.                                                                           |
| initial_cluster_version           | text                     | The initial Kubernetes version for this cluster.                                                    |
| initial_node_count                | bigint                   | The number of nodes to create in this cluster.                                                      |
| instance_group_urls               | jsonb                    | List of urls for instance groups.                                                                   |
| ip_allocation_policy              | jsonb                    | Configuration for cluster IP allocation.                                                            |
| label_fingerprint                 | text                     | The fingerprint of the set of labels for this cluster.                                              |
| legacy_abac_enabled               | boolean                  | Configuration for the legacy ABAC authorization mode.                                               |
| location                          | text                     | The GCP multi-region, region, or zone in which the resource is located.                             |
| location_type                     | text                     | Location type of the cluster i.e REGIONAL/ZONAL.                                                    |
|                          | jsonb                    | The list of Google Compute Engine zones in which the cluster's nodes should be located.             |
| logging_service                   | text                     | The logging service the cluster should use to write logs.                                           |
| maintenance_policy                | jsonb                    | Configure the maintenance policy for this cluster.                                                  |
| master_auth                       | jsonb                    | The authentication information for accessing the master endpoint.                                   |
| master_authorized_networks_config | jsonb                    | The configuration options for master authorized networks feature.                                   |
| max_pods_per_node                 | bigint                   | Constraint enforced on the max num of pods per node.                                                |
| monitoring_service                | text                     | The monitoring service the cluster should use to write metrics.                                     |
| name                              | text                     | The name of this cluster.                                                                           |
| network                           | text                     | The name of the Google Compute Engine network to which the cluster is connected.                    |
| network_config                    | jsonb                    | Configuration for cluster networking.                                                               |
| network_policy                    | jsonb                    | Configuration options for the NetworkPolicy feature.                                                |
| node_config                       | jsonb                    | Parameters used in creating the cluster's nodes.                                                    |
| node_ipv4_cidr_size               | bigint                   | The size of the address space on each node for hosting containers.                                  |
| node_pools                        | jsonb                    | The node pools associated with this cluster.                                                        |
| notification_config               | jsonb                    | Notification configuration of the cluster.                                                          |
| private_cluster_config            | jsonb                    | Configuration for private cluster.                                                                  |
| project                           | text                     | The GCP Project in which the resource is located.                                                   |
| release_channel                   | jsonb                    | Release channel configuration.                                                                      |
| resource_labels                   | jsonb                    | The resource labels for the cluster to use to annotate any related Google Compute Engine resources. |
| resource_usage_export_config      | jsonb                    | Configuration for exporting resource usages.                                                        |
| self_link                         | text                     | Server-defined URL for the resource.                                                                |
| services_ipv4_cidr                | cidr                     | The IP address range of the Kubernetes services in this cluster, in CIDR notation.                  |
| shielded_nodes_enabled            | boolean                  | Denotes whether Shielded Nodes features are enabled on all nodes in this cluster.                   |
| status                            | text                     | The current status of this cluster.                                                                 |
| status_message                    | text                     | Additional information about the current status of this cluster, if available.                      |
| subnetwork                        | text                     | The name of the Google Compute Engine subnetwork to which the cluster is connected.                 |
| tags                              | jsonb                    | A map of tags for the resource.                                                                     |
| title                             | text                     | Title of the resource.                                                                              |
| tpu_ipv4_cidr_block               | cidr                     | The IP address range of the Cloud TPUs in this cluster, in CIDR notation.                           |
| vertical_pod_autoscaling          | jsonb                    | Cluster-level Vertical Pod Autoscaling configuration.                                               |
| workload_identity_config          | jsonb                    | Configuration for the use of Kubernetes Service Accounts in GCP IAM policies.                       |
| zone                              | text                     | The name of the Google Compute Engine zone in which the cluster resides.                            |
+-----------------------------------+--------------------------+-----------------------------------------------------------------------------------------------------+
*/


export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  locations ->> 0 as zone,
  name,
  current_master_version as k8s_version,
  status,
  autoscaling,
  current_node_count as current_node_count,
  node_config ->> 'diskSizeGb' as disk_size_gb,
  node_config ->> 'diskType' as disk_type,
  node_config ->> 'machineType' as machine_type,
  jsonb_array_elements(node_pools) ->> 'name' as pool_name,
  tags as labels
from
  ${TABLE_PREFIX}gcp_kubernetes_cluster
" --output csv 1>gcp_kubernetes_cluster.csv 2>&1
