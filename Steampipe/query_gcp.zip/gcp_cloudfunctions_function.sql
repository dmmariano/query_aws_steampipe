/* .inspect gcp_cloudfunctions_function
+-------------------------------+--------------------------+---------------------------------------------------------------------------------------------------------------+
| column                        | type                     | description                                                                                                   |
+-------------------------------+--------------------------+---------------------------------------------------------------------------------------------------------------+
| _ctx                          | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                                         |
| akas                          | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                                 |
| available_memory_mb           | bigint                   | The amount of memory in MB available for the function.                                                        |
| build_environment_variables   | jsonb                    | Environment variables that shall be available during build time                                               |
| build_id                      | text                     | The Cloud Build ID of the latest successful deployment of the function.                                       |
| description                   | text                     | User-provided description of a function.                                                                      |
| entry_point                   | text                     | The name of the function (as defined in source code) that will be executed.                                   |
| environment_variables         | jsonb                    | Environment variables that shall be available during function execution.                                      |
| event_trigger                 | jsonb                    | A source that fires events in response to a condition in another service.                                     |
| https_trigger                 | jsonb                    | An HTTPS endpoint type of source that can be triggered via URL.                                               |
| iam_policy                    | jsonb                    | The IAM policy for the function.                                                                              |
| ingress_settings              | text                     | The ingress settings for the function, controlling what traffic can reach it (INGRESS_SETTINGS_UNSPECIFIED, A |
|                               |                          | LLOW_ALL, ALLOW_INTERNAL_ONLY, ALLOW_INTERNAL_AND_GCLB).                                                      |
| labels                        | jsonb                    | Labels that apply to this function.                                                                           |
| location                      | text                     | The GCP multi-region, region, or zone in which the resource is located.                                       |
| max_instances                 | bigint                   | The limit on the maximum number of function instances that may coexist at a given time. In some cases, such a |
|                               |                          | s rapid traffic surges, Cloud Functions may, for a short period of time, create more instances than the speci |
|                               |                          | fied max instances limit.                                                                                     |
| name                          | text                     | The name of the function.                                                                                     |
| network                       | text                     | The VPC Network that this cloud function can connect to.                                                      |
| project                       | text                     | The GCP Project in which the resource is located.                                                             |
| runtime                       | text                     | The runtime in which to run the function.                                                                     |
| self_link                     | text                     | Server-defined URL for the resource.                                                                          |
| service_account_email         | text                     | The email of the function's service account.                                                                  |
| source_archive_url            | text                     | The Google Cloud Storage URL, starting with gs://, pointing to the zip archive which contains the function.   |
| source_repository             | text                     | **Beta Feature** The source repository where a function is hosted.                                            |
| source_upload_url             | text                     | The Google Cloud Storage signed URL used for source uploading, generated by google.cloud.functions.v1.Generat |
|                               |                          | eUploadUrl                                                                                                    |
| status                        | text                     | Status of the function deployment (ACTIVE, OFFLINE, CLOUD_FUNCTION_STATUS_UNSPECIFIED,DEPLOY_IN_PROGRESS, DEL |
|                               |                          | ETE_IN_PROGRESS, UNKNOWN).                                                                                    |
| tags                          | jsonb                    | A map of tags for the resource.                                                                               |
| timeout                       | text                     | The function execution timeout. Execution is consideredfailed and can be terminated if the function is not co |
|                               |                          | mpleted at the end of the timeout period. Defaults to 60 seconds.                                             |
| title                         | text                     | Title of the resource.                                                                                        |
| update_time                   | timestamp with time zone | The last update timestamp of the Cloud Function.                                                              |
| version_id                    | bigint                   | The version identifier of the Cloud Function. Each deployment attempt results in a new version of a function  |
|                               |                          | being created.                                                                                                |
| vpc_connector                 | text                     | The VPC Network Connector that this cloud function can  connect to. This field is mutually exclusive with `ne |
|                               |                          | twork` field and will eventually replace it.                                                                  |
| vpc_connector_egress_settings | text                     | The egress settings for the connector, controlling what traffic is diverted through it (VPC_CONNECTOR_EGRESS_ |
|                               |                          | SETTINGS_UNSPECIFIED, PRIVATE_RANGES_ONLY, ALL_TRAFFIC).                                                      |
+-------------------------------+--------------------------+---------------------------------------------------------------------------------------------------------------+
*/

export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  location,
  name,
  status,
  runtime,
  available_memory_mb as memory_mb,
  labels
from
  ${TABLE_PREFIX}gcp_cloudfunctions_function;
" --output csv 1>gcp_cloudfunctions_function.csv 2>&1
