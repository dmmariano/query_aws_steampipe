/* .inspect gcp_kms_key
+--------------------+--------------------------+--------------------------------------------------------------------------------------------------------------------------+
| column             | type                     | description                                                                                                              |
+--------------------+--------------------------+--------------------------------------------------------------------------------------------------------------------------+
| _ctx               | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                                                    |
| akas               | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                                            |
| create_time        | timestamp with time zone | The time at which this CryptoKey was created.                                                                            |
| iam_policy         | jsonb                    | An Identity and Access Management (IAM) policy, which specifies access controls for Google Cloud resources. A `Policy` i |
|                    |                          | s a collection of `bindings`. A `binding` binds one or more `members` to a single `role`. Members can be user accounts,  |
|                    |                          | service accounts, Google groups, and domains (such as G Suite). A `role` is a named list of permissions; each `role` can |
|                    |                          |  be an IAM predefined role or a user-created custom role. For some types of Google Cloud resources, a `binding` can also |
|                    |                          |  specify a `condition`, which is a logical expression that allows access to a resource only if the expression evaluates  |
|                    |                          | to `true`.                                                                                                               |
| key_ring_name      | text                     | The resource name for the KeyRing.                                                                                       |
| labels             | jsonb                    | Labels with user-defined metadata.                                                                                       |
| location           | text                     | The GCP multi-region, region, or zone in which the resource is located.                                                  |
| name               | text                     | The resource name for the CryptoKey.                                                                                     |
| next_rotation_time | timestamp with time zone | At next rotation time, the Key Management Service will automatically: 1. Create a new version of this CryptoKey. 2.Mark  |
|                    |                          | the new version as primary.                                                                                              |
| primary            | jsonb                    | A copy of the primary CryptoKeyVersion that will be used by Encrypt when this CryptoKey is given in EncryptRequest.name. |
| project            | text                     | The GCP Project in which the resource is located.                                                                        |
| purpose            | text                     | The immutable purpose of this CryptoKey.                                                                                 |
| rotation_period    | text                     | Next rotation time will be advanced by this period when the service automatically rotates a key.                         |
| self_link          | text                     | Server-defined URL for the resource.                                                                                     |
| tags               | jsonb                    | A map of tags for the resource.                                                                                          |
| title              | text                     | Title of the resource.                                                                                                   |
| version_template   | jsonb                    | A template describing settings for new CryptoKeyVersion instances.                                                       |
+--------------------+--------------------------+--------------------------------------------------------------------------------------------------------------------------+
*/


export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  location,
  name,
  rotation_period,
  labels
from
  ${TABLE_PREFIX}gcp_kms_key;
" --output csv > gcp_kms_key.csv 2>&1
