/* .inspect gcp_pubsub_topic
+----------------------------------------------------+-------+-------------------------------------------------------------------------------------------------------------+
| column                                             | type  | description                                                                                                 |
+----------------------------------------------------+-------+-------------------------------------------------------------------------------------------------------------+
| _ctx                                               | jsonb | Steampipe context in JSON form, e.g. connection_name.                                                       |
| akas                                               | jsonb | Array of globally unique identifier strings (also known as) for the resource.                               |
| iam_policy                                         | jsonb | An Identity and Access Management (IAM) policy, which specifies access controls for Google Cloud resources. |
|                                                    |       |  A `Policy` is a collection of `bindings`. A `binding` binds one or more `members` to a single `role`. Memb |
|                                                    |       | ers can be user accounts, service accounts, Google groups, and domains (such as G Suite). A `role` is a nam |
|                                                    |       | ed list of permissions; each `role` can be an IAM predefined role or a user-created custom role. For some t |
|                                                    |       | ypes of Google Cloud resources, a `binding` can also specify a `condition`, which is a logical expression t |
|                                                    |       | hat allows access to a resource only if the expression evaluates to `true`.                                 |
| kms_key_name                                       | text  | The resource name of the Cloud KMS CryptoKey to be used to protect access to messages published on this top |
|                                                    |       | ic.                                                                                                         |
| labels                                             | jsonb | A set of labels attached with the topic.                                                                    |
| location                                           | text  | The GCP multi-region, region, or zone in which the resource is located.                                     |
| message_storage_policy_allowed_persistence_regions | jsonb | Policy constraining the set of Google Cloud Platform regions where messages published to the topic may be s |
|                                                    |       | tored. If not present, then no constraints are in effect.                                                   |
| name                                               | text  | The name of the topic.                                                                                      |
| project                                            | text  | The GCP Project in which the resource is located.                                                           |
| self_link                                          | text  | Server-defined URL for the resource.                                                                        |
| tags                                               | jsonb | A map of tags for the resource.                                                                             |
| title                                              | text  | Title of the resource.                                                                                      |
+----------------------------------------------------+-------+-------------------------------------------------------------------------------------------------------------+
*/

export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project as Project,
  location as Location,
  name as Name,
  labels
from
  ${TABLE_PREFIX}gcp_pubsub_topic;
" --output csv 1>gcp_pubsub_topic.csv 2>&1