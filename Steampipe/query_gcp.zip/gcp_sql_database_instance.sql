/*
+------------------------------------------+--------------------------+----------------------------------------------------------------------------------------------------+
| column                                   | type                     | description                                                                                        |
+------------------------------------------+--------------------------+----------------------------------------------------------------------------------------------------+
| _ctx                                     | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                              |
| activation_policy                        | text                     | Describes the activation policy specifies when the instance is activated.                          |
| akas                                     | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                      |
| authorized_gae_applications              | jsonb                    | A list of App Engine app IDs, that can access this instance.                                       |
| availability_type                        | text                     | Specifies the availability type of the instance. This field is used only for PostgreSQL and MySQL  |
|                                          |                          | instances.                                                                                         |
| backend_type                             | text                     | Specifies the backend type. Possible values are: FIRST_GEN, SECOND_GEN, EXTERNAL, and SQL_BACKEND_ |
|                                          |                          | TYPE_UNSPECIFIED.                                                                                  |
| backup_enabled                           | boolean                  | Indicates whether backup configuration is enabled, or not.                                         |
| backup_location                          | text                     | Specifies the backup location.                                                                     |
| backup_replication_log_archiving_enabled | boolean                  | Indicates whether backup replication log archiving is enabled, or not.                             |
| backup_start_time                        | text                     | Specifies the start time for the daily backup configuration.                                       |
| binary_log_enabled                       | boolean                  | Indicates whether binary log is enabled, or not.                                                   |
| can_defer_maintenance                    | boolean                  | Indicates whether the scheduled maintenance can be deferred, or not.                               |
| can_reschedule_maintenance               | boolean                  | Indicates whether the scheduled maintenance can be rescheduled, or not.                            |
| connection_name                          | text                     | Specifies the connection name of the Cloud SQL instance used in connection strings.                |
| crash_safe_replication_enabled           | boolean                  | Specifies whether the database flags for crash-safe replication are enabled, or not.               |
| current_disk_size                        | bigint                   | Specifies the current disk usage of the instance in bytes.                                         |
| data_disk_size_gb                        | bigint                   | Specifies the size of the data disk, in GB. Minimum size is 10GB. Not used for First Generation in |
|                                          |                          | stances.                                                                                           |
| data_disk_type                           | text                     | Specifies the type of the data disk used for this instance.                                        |
| database_flags                           | jsonb                    | A list of database flags passed to the instance at startup.                                        |
| database_replication_enabled             | boolean                  | Specifies whether the replication of database is enabled, or not.                                  |
| database_version                         | text                     | Specifies the type and version of the database engine.                                             |
| enable_point_in_time_recovery            | boolean                  | Allows user to recover data from a specific point in time, down to a fraction of a second.         |
| failover_replica_available               | boolean                  | The availability status of the failover replica. A false status indicates that the failover replic |
|                                          |                          | a is out of sync.                                                                                  |
| failover_replica_name                    | text                     | The name of the failover replica. If specified at instance creation, a failover replica is created |
|                                          |                          |  for the instance.                                                                                 |
| gce_zone                                 | text                     | Specifies the Compute Engine zone that the instance is currently serving from.                     |
| instance_type                            | text                     | Specifies the type of the instance.                                                                |
| instance_users                           | jsonb                    | A list of users in the specified Cloud SQL instance.                                               |
| ip_addresses                             | jsonb                    | A list of assigned IP addresses for the instance.                                                  |
| ip_configuration                         | jsonb                    | Describes the settings for IP management. It allows to enable or disable the instance IP and manag |
|                                          |                          | e which external networks can connect to the instance.                                             |
| ipv6_address                             | inet                     | Specifies the IPv6 address assigned to the instance. This property is applicable only to First Gen |
|                                          |                          | eration instances.                                                                                 |
| kind                                     | text                     | The type of the resource.                                                                          |
| kms_key_name                             | text                     | Specifies the resource name of KMS key used for disk encryption.                                   |
| kms_key_version_name                     | text                     | Specifies the KMS key version used to encrypt the Cloud SQL instance.                              |
| labels                                   | jsonb                    | A label is a key-value pair that helps you organize your Google Cloud instances. You can attach a  |
|                                          |                          | label to each resource, then filter the resources based on their labels.                           |
| location                                 | text                     | The GCP multi-region, region, or zone in which the resource is located.                            |
| location_preference                      | jsonb                    | Describes the location preference settings. This allows the instance to be located as near as poss |
|                                          |                          | ible to either an App Engine app or Compute Engine zone for better performance.                    |
| machine_type                             | text                     | Specifies the tier or machine type for this instance.                                              |
| maintenance_start_time                   | timestamp with time zone | The start time of any upcoming scheduled maintenance for this instance.                            |
| maintenance_window                       | jsonb                    | Describes the maintenance window for this instance.                                                |
| master_instance_name                     | text                     | Specifies the name of the instance which will act as master in the replication setup.              |
| max_disk_size                            | bigint                   | Specifies the maximum disk size of the instance in bytes.                                          |
| name                                     | text                     | A friendly name that identifies the resource.                                                      |
| on_premises_configuration                | jsonb                    | Describes the configurations specific to on-premises instances.                                    |
| pricing_plan                             | text                     | Specifies the pricing plan for this instance.                                                      |
| project                                  | text                     | The GCP Project in which the resource is located.                                                  |
| replica_names                            | jsonb                    | A list of replicas of the instance.                                                                |
| replication_configuration                | jsonb                    | Describes the configurations specific to failover replicas and read replicas.                      |
| replication_type                         | text                     | Specifies the type of replication this instance uses.                                              |
| self_link                                | text                     | The server-defined URL for the resource.                                                           |
| service_account_email_address            | text                     | The service account email address assigned to the instance. This property is applicable only to Se |
|                                          |                          | cond Generation instances.                                                                         |
| settings_version                         | bigint                   | Specifies the version of instance settings.                                                        |
| ssl_configuration                        | jsonb                    | Describes the SSL configuration of the instance.                                                   |
| state                                    | text                     | Specifies the current serving state of the Cloud SQL instance.                                     |
| storage_auto_resize                      | boolean                  | Specifies whether the configuration for automatic increment of the the storage size is enabled, or |
|                                          |                          |  not.                                                                                              |
| storage_auto_resize_limit                | bigint                   | Specifies the maximum size to which storage capacity can be automatically increased.               |
| suspension_reason                        | jsonb                    | A list of reasons for the suspension, if the instance state is SUSPENDED.                          |
| tags                                     | jsonb                    | A map of tags for the resource.                                                                    |
| title                                    | text                     | Title of the resource.                                                                             |
+------------------------------------------+--------------------------+----------------------------------------------------------------------------------------------------+
*/


export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  gce_zone as zone,
  name,
  state,
  database_version,
  data_disk_type as disk_type,
  data_disk_size_gb as disk_gb,
  machine_type,
  labels
from
  ${TABLE_PREFIX}gcp_sql_database_instance;
" --output csv >gcp_sql_database_instance.csv 2>&1