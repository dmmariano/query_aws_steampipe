/* .inspect gcp_dns_managed_zone
+--------------------------------------------------+--------------------------+---------------------------------------+
| column                                           | type                     | description                           |
+--------------------------------------------------+--------------------------+---------------------------------------+
| _ctx                                             | jsonb                    | Steampipe context in JSON form, e.g.  |
|                                                  |                          | connection_name.                      |
| akas                                             | jsonb                    | Array of globally unique identifier s |
|                                                  |                          | trings (also known as) for the resour |
|                                                  |                          | ce.                                   |
| creation_time                                    | timestamp with time zone | The time that this resource was creat |
|                                                  |                          | ed on the server.                     |
| description                                      | text                     | A user-specified, human-readable desc |
|                                                  |                          | ription of the managed zone.          |
| dns_name                                         | text                     | The DNS name of this managed zone.    |
| dnssec_config_default_key_specs                  | jsonb                    | Specifies parameters for generating i |
|                                                  |                          | nitial DnsKeys for this ManagedZone.  |
| dnssec_config_non_existence                      | text                     | Specifies the mechanism for authentic |
|                                                  |                          | ated denial-of-existence responses.   |
| dnssec_config_state                              | text                     | Specifies whether DNSSEC is enabled,  |
|                                                  |                          | and what mode it is in.               |
| forwarding_config_target_name_servers            | jsonb                    | A list of target name servers to forw |
|                                                  |                          | ard to.                               |
| id                                               | bigint                   | The unique identifier for the resourc |
|                                                  |                          | e, defined by the server.             |
| kind                                             | text                     | The type of the resource.             |
| labels                                           | jsonb                    | A set labels attached with the resour |
|                                                  |                          | ce.                                   |
| location                                         | text                     | The GCP multi-region, region, or zone |
|                                                  |                          |  in which the resource is located.    |
| name                                             | text                     | An user assigned, friendly name that  |
|                                                  |                          | identifies the resource.              |
| name_server_set                                  | text                     | Specifies the NameServerSet for this  |
|                                                  |                          | ManagedZone. A NameServerSet is a set |
|                                                  |                          |  of DNS name servers that all host th |
|                                                  |                          | e same ManagedZones.                  |
| name_servers                                     | jsonb                    | Delegate your managed_zone to these v |
|                                                  |                          | irtual name servers; defined by the s |
|                                                  |                          | erver.                                |
| peering_config_target_network                    | jsonb                    | Specifies the configuration of the ne |
|                                                  |                          | twork with which to peer.             |
| private_visibility_config_networks               | jsonb                    | A set of Virtual Private Cloud resour |
|                                                  |                          | ces that the zone is visible from.    |
| project                                          | text                     | The GCP Project in which the resource |
|                                                  |                          |  is located.                          |
| self_link                                        | text                     | Server-defined URL for the managed zo |
|                                                  |                          | ne.                                   |
| service_directory_config_namespace_deletion_time | timestamp with time zone | The time that the namespace backing t |
|                                                  |                          | his zone was deleted.                 |
| tags                                             | jsonb                    | A map of tags for the resource.       |
| title                                            | text                     | Title of the resource.                |
| visibility                                       | text                     | Specifies the zone's visibility. publ |
|                                                  |                          | ic zones are exposed to the Internet, |
|                                                  |                          |  while private zones are visible only |
|                                                  |                          |  to Virtual Private Cloud resources.  |
+--------------------------------------------------+--------------------------+---------------------------------------+
*/

export TABLE_PREFIX="jslcloud."

time steampipe query "
select
  project,
  location,
  dns_name,
  visibility,
  labels
from
  ${TABLE_PREFIX}gcp_dns_managed_zone;
" --output csv 1>gcp_dns_managed_zone.csv 2>&1