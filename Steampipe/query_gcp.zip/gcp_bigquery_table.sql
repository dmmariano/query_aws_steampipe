/* .inspect gcp_bigquery_table;
+-----------------------------+--------------------------+-----------------------------------------------------------------------------------------------------------------+
| column                      | type                     | description                                                                                                     |
+-----------------------------+--------------------------+-----------------------------------------------------------------------------------------------------------------+
| _ctx                        | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                                           |
| akas                        | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                                   |
| clustering_fields           | jsonb                    | One or more fields on which data should be clustered.                                                           |
| creation_time               | timestamp with time zone | The time when this table was created, in milliseconds since the epoch.                                          |
| dataset_id                  | text                     | The ID of the dataset containing this table.                                                                    |
| description                 | text                     | A user-friendly description of this table.                                                                      |
| etag                        | text                     | A hash of the table metadata, used to ensure there were no concurrent modifications to the resource when attemp |
|                             |                          | ting an update.                                                                                                 |
| expiration_time             | timestamp with time zone | The time when this table expires, in milliseconds since the epoch. If not present, the table will persist indef |
|                             |                          | initely. Expired tables will be deleted and their storage reclaimed. The defaultTableExpirationMs property of t |
|                             |                          | he encapsulating dataset can be used to set a default expirationTime on newly created tables.                   |
| external_data_configuration | jsonb                    | Describes the data format, location, and other properties of a table stored outside of BigQuery.                |
| id                          | text                     | An opaque ID uniquely identifying the table.                                                                    |
| kind                        | text                     | The type of resource ID.                                                                                        |
| kms_key_name                | text                     | Describes the Cloud KMS encryption key that will be used to protect destination BigQuery table.                 |
| labels                      | jsonb                    | The labels associated with this table. You can use these to organize and group your tables. Label keys and valu |
|                             |                          | es can be no longer than 63 characters, can only contain lowercase letters, numeric characters, underscores and |
|                             |                          |  dashes. International characters are allowed. Label values are optional. Label keys must start with a letter a |
|                             |                          | nd each label in the list must have a different key.                                                            |
| last_modified_time          | timestamp with time zone | The time when this table was last modified.                                                                     |
| location                    | text                     | The GCP multi-region, region, or zone in which the resource is located.                                         |
| materialized_view           | jsonb                    | Describes materialized view definition.                                                                         |
| name                        | text                     | A descriptive name for this table, if one exists.                                                               |
| num_bytes                   | bigint                   | The size of this table in bytes, excluding any data in the streaming buffer.                                    |
| num_long_term_bytes         | bigint                   | The number of bytes in the table that are considered 'long-term storage'.                                       |
| num_physical_bytes          | bigint                   | The physical size of this table in bytes, excluding any data in the streaming buffer.                           |
| num_rows                    | bigint                   | The number of rows of data in this table, excluding any data in the streaming buffer.                           |
| project                     | text                     | The GCP Project in which the resource is located.                                                               |
| range_partitioning          | jsonb                    | If specified, configures range partitioning for this table.                                                     |
| require_partition_filter    | boolean                  | If set to true, queries over this table require a partition filter that can be used for partition elimination t |
|                             |                          | o be specified.                                                                                                 |
| schema_fields               | jsonb                    | Describes the fields in a table.                                                                                |
| self_link                   | text                     | A URL that can be used to access this resource again.                                                           |
| snapshot_time               | timestamp with time zone | The time at which the base table was snapshot.                                                                  |
| streaming_buffer            | jsonb                    | Contains information regarding this table's streaming buffer, if one is present.                                |
| table_id                    | text                     | The ID of the table resource.                                                                                   |
| tags                        | jsonb                    | A map of tags for the resource.                                                                                 |
| time_partitioning           | jsonb                    | If specified, configures time-based partitioning for this table.                                                |
| title                       | text                     | Title of the resource.                                                                                          |
| type                        | text                     | The type of table. Possible values are: TABLE, VIEW.                                                            |
| view                        | jsonb                    | dditional details for a view.                                                                                   |
| view_query                  | text                     | A query that BigQuery executes when the view is referenced.                                                     |
| view_use_legacy_sql         | boolean                  | True if view is defined in legacy SQL dialect, false if in standard SQL.                                        |
+-----------------------------+--------------------------+-----------------------------------------------------------------------------------------------------------------+
*/

export TABLE_PREFIX="movidacloud_dw_1."

time steampipe query "
select
  project,
  location,
  title,
  num_bytes /1024 as table_size_mb,
  num_long_term_bytes table_size_mb_long_term,
  labels
from
  ${TABLE_PREFIX}gcp_bigquery_table;
" --output csv 1>${TABLE_PREFIX}gcp_bigquery_table.csv 2>&1

