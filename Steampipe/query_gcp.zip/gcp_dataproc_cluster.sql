/* .inspect gcp_dataproc_cluster
+----------------+-------+----------------------------------------------------------------------------------------------------------+
| column         | type  | description                                                                                              |
+----------------+-------+----------------------------------------------------------------------------------------------------------+
| _ctx           | jsonb | Steampipe context in JSON form, e.g. connection_name.                                                    |
| akas           | jsonb | Array of globally unique identifier strings (also known as) for the resource.                            |
| cluster_name   | text  | The cluster name.                                                                                        |
| cluster_uuid   | text  | A cluster UUID (Unique Universal Identifier). Dataproc generates this value when it creates the cluster. |
| config         | jsonb | The cluster config.                                                                                      |
| labels         | jsonb | The labels to associate with this cluster.                                                               |
| location       | text  | The GCP multi-region, region, or zone in which the resource is located.                                  |
| metrics        | jsonb | Contains cluster daemon metrics such as HDFS and YARN stats.                                             |
| project        | text  | The GCP Project in which the resource is located.                                                        |
| self_link      | text  | Server-defined URL for the resource.                                                                     |
| state          | text  | The cluster's state.                                                                                     |
| status         | jsonb | Cluster status.                                                                                          |
| status_history | jsonb | The previous cluster status.                                                                             |
| tags           | jsonb | A map of tags for the resource.                                                                          |
| title          | text  | Title of the resource.                                                                                   |
+----------------+-------+----------------------------------------------------------------------------------------------------------+
*/

export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  location,
  cluster_name,
  config,
  status,
  state,
  labels
from
  ${TABLE_PREFIX}gcp_dataproc_cluster;
" --output csv 1>gcp_dataproc_cluster.csv 2>&1