/*
+-----------------------------------------+--------+-------------------------------------------------------------------------------+
| column                                  | type   | description                                                                   |
+-----------------------------------------+--------+-------------------------------------------------------------------------------+
| _ctx                                    | jsonb  | Steampipe context in JSON form, e.g. connection_name.                         |
| akas                                    | jsonb  | Array of globally unique identifier strings (also known as) for the resource. |
| charset                                 | text   | Specifies the MySQL charset value.                                            |
| collation                               | text   | Specifies the MySQL collation value.                                          |
| instance_name                           | text   | The name of the Cloud SQL instance.                                           |
| kind                                    | text   | The type of the resource.                                                     |
| location                                | text   | The GCP multi-region, region, or zone in which the resource is located.       |
| name                                    | text   | A friendly name that identifies the resource.                                 |
| project                                 | text   | The GCP Project in which the resource is located.                             |
| self_link                               | text   | The server-defined URL for the resource.                                      |
| sql_server_database_compatibility_level | bigint | The version of SQL Server with which the database is to be made compatible.   |
| sql_server_database_recovery_model      | text   | The recovery model of a SQL Server database.                                  |
| title                                   | text   | Title of the resource.                                                        |
+-----------------------------------------+--------+-------------------------------------------------------------------------------+
*/


export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  instance_name,
  name as db_name,
  charset,
  \"collation\"
from
  ${TABLE_PREFIX}gcp_sql_database;
" --output csv 1>gcp_sql_database.csv 2>&1