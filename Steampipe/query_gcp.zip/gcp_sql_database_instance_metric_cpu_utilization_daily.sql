/*
+--------------------+--------------------------+--------------------------------------------------------------------------------------------------------------------------+
| column             | type                     | description                                                                                                              |
+--------------------+--------------------------+--------------------------------------------------------------------------------------------------------------------------+
| _ctx               | jsonb                    | Steampipe context in JSON form.                                                                                          |
| average            | double precision         | The average of the metric values that correspond to the data point.                                                      |
| location           | text                     | The GCP multi-region, region, or zone in which the resource is located.                                                  |
| maximum            | double precision         | The maximum metric value for the data point.                                                                             |
| metadata           | jsonb                    | The associated monitored resource metadata.                                                                              |
| metric_kind        | text                     | The metric type.                                                                                                         |
| metric_labels      | jsonb                    | The set of label values that uniquely identify this metric.                                                              |
| metric_type        | text                     | The associated metric. A fully-specified metric used to identify the time series.                                        |
| minimum            | double precision         | The minimum metric value for the data point.                                                                             |
| name               | text                     | The name of the instance.                                                                                                |
| project            | text                     | The GCP Project in which the resource is located.                                                                        |
| resource           | jsonb                    | The associated monitored resource.                                                                                       |
| sample_count       | double precision         | The number of metric values that contributed to the aggregate value of this data point.                                  |
| sp_connection_name | text                     | Steampipe connection name.                                                                                               |
| sp_ctx             | jsonb                    | Steampipe context in JSON form.                                                                                          |
| sum                | double precision         | The sum of the metric values for the data point.                                                                         |
| timestamp          | timestamp with time zone | The time stamp used for the data point.                                                                                  |
| unit               | text                     | The data points of this time series. When listing time series, points are returned in reverse time order.When creating a |
|                    |                          |  time series, this field must contain exactly one point and the point's type must be the same as the value type of the a |
|                    |                          | ssociated metric. If the associated metric's descriptor must be auto-created, then the value type of the descriptor is d |
|                    |                          | etermined by the point's type, which must be BOOL, INT64, DOUBLE, or DISTRIBUTION.                                       |
+--------------------+--------------------------+--------------------------------------------------------------------------------------------------------------------------+
*/


export TABLE_PREFIX="jslcloud."
time steampipe query "
select
    project,
    location,
    timestamp,
    instance_id as instance_name,
    (minimum*100) as min,
    (maximum*100) as max,
    (average*100) as avg,
    sample_count
from
    ${TABLE_PREFIX}gcp_sql_database_instance_metric_cpu_utilization_daily
order by 
    instance_id
" --output csv 1>gcp_sql_database_instance_metric_cpu_utilization_daily.csv 2>&1