/* .inspect gcp_storage_object
+----------------------------+--------------------------+------------------------------------------------------------------------------------------------------------------+
| column                     | type                     | description                                                                                                      |
+----------------------------+--------------------------+------------------------------------------------------------------------------------------------------------------+
| _ctx                       | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                                            |
| acl                        | jsonb                    | Access controls on the object.                                                                                   |
| akas                       | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.                                    |
| bucket                     | text                     | The name of the bucket containing this object.                                                                   |
| cache_control              | text                     | Cache-Control directive for the object data.                                                                     |
| component_count            | bigint                   | Number of underlying components that make up this object.                                                        |
| content_disposition        | text                     | Content-Disposition of the object data.                                                                          |
| content_encoding           | text                     | Content-Encoding of the object data.                                                                             |
| content_language           | text                     | Content-Language of the object data.                                                                             |
| content_type               | text                     | Content-Type of the object data.                                                                                 |
| crc32c                     | text                     | CRC32c checksum, as described in RFC 4960, Appendix B; encoded using base64 in big-endian byte order.            |
| custom_time                | timestamp with time zone | A timestamp in RFC 3339 format specified by the user for an object                                               |
| customer_encryption        | jsonb                    | Metadata of customer-supplied encryption key, if the object is encrypted by such a key                           |
| etag                       | text                     | Entity tag for the object                                                                                        |
| event_based_hold           | boolean                  | Whether or not the object is under event-based hold.                                                             |
| generation                 | bigint                   | The content generation of this object.                                                                           |
| iam_policy                 | jsonb                    | An Identity and Access Management (IAM) policy, which specifies access controls for Google Cloud resources. A `P |
|                            |                          | olicy` is a collection of `bindings`. A `binding` binds one or more `members` to a single `role`. Members can be |
|                            |                          |  user accounts, service accounts, Google groups, and domains (such as G Suite). A `role` is a named list of perm |
|                            |                          | issions; each `role` can be an IAM predefined role or a user-created custom role. For some types of Google Cloud |
|                            |                          |  resources, a `binding` can also specify a `condition`, which is a logical expression that allows access to a re |
|                            |                          | source only if the expression evaluates to `true`.                                                               |
| id                         | text                     | The ID of the object, including the bucket name, object name, and generation number.                             |
| kind                       | text                     | The kind of item this is.                                                                                        |
| kms_key_name               | text                     | Cloud KMS Key used to encrypt this object, if the object is encrypted by such a key.                             |
| md5_hash                   | text                     | MD5 hash of the data; encoded using base64                                                                       |
| media_link                 | text                     | Media download link                                                                                              |
| metadata                   | text                     | User-provided metadata, in key/value pairs.                                                                      |
| metageneration             | bigint                   | The version of the metadata for this object at this generation.                                                  |
| name                       | text                     | The name of the object.                                                                                          |
| owner                      | jsonb                    | The owner of the object. This will always be the uploader of the object.                                         |
| project                    | text                     | The GCP Project in which the resource is located.                                                                |
| retention_expiration_time  | timestamp with time zone | A server-determined value that specifies the earliest time that the object's retention period expires.           |
| self_link                  | text                     | The link to this object.                                                                                         |
| size                       | bigint                   | Content-Length of the data in bytes.                                                                             |
| storage_class              | text                     | Storage class of the object.                                                                                     |
| temporary_hold             | boolean                  | Whether or not the object is under temporary hold.                                                               |
| time_created               | timestamp with time zone | The creation time of the object.                                                                                 |
| time_deleted               | timestamp with time zone | The deletion time of the object.                                                                                 |
| time_storage_class_updated | timestamp with time zone | The time at which the object's storage class was last changed.                                                   |
| title                      | text                     | Title of the resource.                                                                                           |
| updated                    | timestamp with time zone | The modification time of the object metadata.                                                                    |
+----------------------------+--------------------------+------------------------------------------------------------------------------------------------------------------+

> .inspect gcp_storage_bucket
+-------------------------------------------------------+--------------------------+---------------------------------------------------------------------------------------+
| column                                                | type                     | description                                                                           |
+-------------------------------------------------------+--------------------------+---------------------------------------------------------------------------------------+
| _ctx                                                  | jsonb                    | Steampipe context in JSON form, e.g. connection_name.                                 |
| acl                                                   | jsonb                    | An access-control list                                                                |
| akas                                                  | jsonb                    | Array of globally unique identifier strings (also known as) for the resource.         |
| billing_requester_pays                                | boolean                  | When set to true, Requester Pays is enabled for this bucket.                          |
| cors                                                  | jsonb                    | The bucket's Cross-Origin Resource Sharing (CORS) configuration.                      |
| default_event_based_hold                              | boolean                  | The default value for event-based hold on newly created objects in this bucket. Event |
|                                                       |                          | -based hold is a way to retain objects indefinitely until an event occurs, signified  |
|                                                       |                          | by the hold's release. After being released, such objects will be subject to bucket-l |
|                                                       |                          | evel retention (if any).                                                              |
| default_kms_key_name                                  | text                     | A Cloud KMS key that will be used to encrypt objects inserted into this bucket, if no |
|                                                       |                          |  encryption method is specified.                                                      |
| default_object_acl                                    | jsonb                    | Lists of object access control entries                                                |
| etag                                                  | text                     | HTTP 1.1 Entity tag for the bucket.                                                   |
| iam_configuration_bucket_policy_only_enabled          | boolean                  | The bucket's uniform bucket-level access configuration. The feature was formerly know |
|                                                       |                          | n as Bucket Policy Only. For backward compatibility, this field will be populated wit |
|                                                       |                          | h identical information as the uniformBucketLevelAccess field.                        |
| iam_configuration_public_access_prevention            | text                     | The bucket's Public Access Prevention configuration. Currently, 'unspecified' and 'en |
|                                                       |                          | forced' are supported.                                                                |
| iam_configuration_uniform_bucket_level_access_enabled | boolean                  | The bucket's uniform bucket-level access configuration.                               |
| iam_policy                                            | jsonb                    | An Identity and Access Management (IAM) policy, which specifies access controls for G |
|                                                       |                          | oogle Cloud resources. A `Policy` is a collection of `bindings`. A `binding` binds on |
|                                                       |                          | e or more `members` to a single `role`. Members can be user accounts, service account |
|                                                       |                          | s, Google groups, and domains (such as G Suite). A `role` is a named list of permissi |
|                                                       |                          | ons; each `role` can be an IAM predefined role or a user-created custom role. For som |
|                                                       |                          | e types of Google Cloud resources, a `binding` can also specify a `condition`, which  |
|                                                       |                          | is a logical expression that allows access to a resource only if the expression evalu |
|                                                       |                          | ates to `true`.                                                                       |
| id                                                    | text                     | The ID of the bucket. For buckets, the id and name properties are the same.           |
| kind                                                  | text                     | The kind of item this is. For buckets, this is always storage#bucket.                 |
| labels                                                | jsonb                    | Labels that apply to this bucket.                                                     |
| lifecycle_rules                                       | jsonb                    | The bucket's lifecycle configuration. See lifecycle management for more information.  |
| location                                              | text                     | The GCP multi-region, region, or zone in which the resource is located.               |
| location_type                                         | text                     | The type of the bucket location.                                                      |
| log_bucket                                            | text                     | The destination bucket where the current bucket's logs should be placed.              |
| log_object_prefix                                     | text                     | A prefix for log object names.                                                        |
| metageneration                                        | bigint                   | The metadata generation of this bucket.                                               |
| name                                                  | text                     | The name of the bucket.                                                               |
| owner_entity                                          | text                     | The entity, in the form project-owner-projectId. This is always the project team's ow |
|                                                       |                          | ner group.                                                                            |
| owner_entity_id                                       | text                     | The ID for the entity.                                                                |
| project                                               | text                     | The GCP Project in which the resource is located.                                     |
| project_number                                        | double precision         | The project number of the project the bucket belongs to.                              |
| retention_policy                                      | jsonb                    | The bucket's retention policy. The retention policy enforces a minimum retention time |
|                                                       |                          |  for all objects contained in the bucket, based on their creation time. Any attempt t |
|                                                       |                          | o overwrite or delete objects younger than the retention period will result in a PERM |
|                                                       |                          | ISSION_DENIED error.                                                                  |
| self_link                                             | text                     | The URI of this bucket.                                                               |
| storage_class                                         | text                     | The bucket's default storage class, used whenever no storageClass is specified for a  |
|                                                       |                          | newly-created object. This defines how objects in the bucket are stored and determine |
|                                                       |                          | s the SLA and the cost of storage. Values include MULTI_REGIONAL, REGIONAL, STANDARD, |
|                                                       |                          |  NEARLINE, COLDLINE, ARCHIVE, and DURABLE_REDUCED_AVAILABILITY. If this value is not  |
|                                                       |                          | specified when the bucket is created, it will default to STANDARD.                    |
| tags                                                  | jsonb                    | A map of tags for the resource.                                                       |
| time_created                                          | timestamp with time zone | The creation time of the bucket in RFC 3339 format.                                   |
| title                                                 | text                     | Title of the resource.                                                                |
| updated                                               | timestamp with time zone | The modification time of the bucket.                                                  |
| versioning_enabled                                    | boolean                  | While set to true, versioning is fully enabled for this bucket.                       |
| website_main_page_suffix                              | text                     | If the requested object path is missing, the service will ensure the path has a trail |
|                                                       |                          | ing '/', append this suffix, and attempt to retrieve the resulting object. This allow |
|                                                       |                          | s the creation of index.html objects to represent directory pages.                    |
| website_not_found_page                                | text                     | If the requested object path is missing, and any mainPageSuffix object is missing, if |
|                                                       |                          |  applicable, the service will return the named object from this bucket as the content |
|                                                       |                          |  for a 404 Not Found result.                                                          |
+-------------------------------------------------------+--------------------------+---------------------------------------------------------------------------------------+
*/


export TABLE_PREFIX="jslcloud."
time steampipe query "
select
  project,
  location,
  name,
  storage_class,
  versioning_enabled,
  labels
from
  ${TABLE_PREFIX}gcp_storage_bucket;
" --output csv 1>.gcp_storage_bucket.tmp 2>&1